#!/usr/bin/env python3
"""Base única de atenciones: todas las fuentes, un solo layout.

DECISIÓN (19-ago-2026): una sola tabla, con la estructura del LayoutMaster, y
TODOS los registros dentro. Las listas semanales que mandan las dependencias son
tan fundamentales como el SUAC — de hecho son la mayoría de la gente atendida
que el SUAC nunca ve.

El layout es un CONTRATO: las 20 columnas, en este orden, siempre. Ninguna
fuente agrega columnas propias; lo que no cabe, no entra (y se reporta).

FUENTES
  1. `BDDConcentrado_General_Unificado_13ago.xlsx` — 106 pestañas de 10 áreas,
     97 ya en layout y 9 heredadas con el formato roto de origen.
  2. `CESAC - BASE SUAC (260812).xlsx` — el SUAC, única fuente que NO viene en
     layout: se traduce columna por columna.
  3. `Concentrado_AmazonicaIA_13ago.xlsx`, hoja `BlankSpace` — el bot de WhatsApp.

FOLIO. Es la llave y no todas las fuentes lo traen. Cuando falta se sintetiza
uno deterministico —`CUH/<DEP>/<hash>`— derivado de la firma estable de la fila
(nombre + teléfono + fecha + servicio), NUNCA de su posición: así el mismo
registro recibe el mismo folio en cada reconstrucción y el archivo es diffeable.

TRAMPAS YA PAGADAS que aquí se respetan (ver incremento_13ago.py):
  · placeholders S/D pegados al nombre, que rompen el empate con el padrón
  · el tipo del teléfono cambia entre cortes ('55…' vs '55….0')
  · fechas en texto y seriales de Excel conviviendo en la misma columna
  · hojas sin encabezado con dos layouts mezclados (JUR_ASESORÍAS)
  · hojas basura cuyo conteo no es el que dice el Índice

    python3 base_unica.py
"""
import collections
import csv
import hashlib
import os
import re
import unicodedata
from datetime import date, datetime

import pandas as pd

import arbol_servicios as arb
import xlcache as xl

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, 'base_unica')
DES = os.path.expanduser('~/Downloads/drive-download-20260817T051938Z-1-001')
LIBRO = os.path.join(DES, 'BDDConcentrado_General_Unificado_13ago.xlsx')
SUAC = os.path.join(DES, 'CESAC - BASE SUAC (260812).xlsx')
AMZ = os.path.join(DES, 'Concentrado_AmazonicaIA_13ago.xlsx')
CORTE = '2026-08-13'

# EL CONTRATO. Estas 20, en este orden, para todos los registros.
LAYOUT = ['nombre', 'apellido_paterno', 'ApellidoM', 'Sexo', 'Teléfono', 'colonia',
          'Territorial', 'seccion', 'calle', 'numero', 'Nacimiento', 'CURP',
          'Nacionalidad', 'fecha', 'lat', 'lng', 'observaciones', 'Dependencia',
          'servicio', 'Folio']

# prefijo de pestaña -> dependencia, con la clave que ya usa el padrón
DEPS = {'CULT': 'Cultura', 'DS': 'Desarrollo Social', 'EG': 'Genero',
        'GOB': 'Gobierno', 'JUR': 'Jurídico', 'OBRAS': 'Obras', 'SEG': 'Seguridad',
        'SU': 'Servicios Urbanos', 'PC-PCyVS': 'Protección Civil',
        'PC-GIRPC': 'Protección Civil'}
# el área administrativa del SUAC -> misma clave
AREA_SUAC = {
    'DIRECCIÓN GENERAL DE SERVICIOS URBANOS': 'Servicios Urbanos',
    'DIRECCIÓN GENERAL DE GOBIERNO': 'Gobierno',
    'DIRECCIÓN GENERAL DE SEGURIDAD CIUDADANA': 'Seguridad',
    'DIRECCIÓN GENERAL DE CULTURA Y EDUCACIÓN': 'Cultura',
    'DIRECCIÓN DE PROTECCIÓN CIVIL': 'Protección Civil',
    'DIRECCIÓN GENERAL DE OBRAS Y DESARROLLO URBANO': 'Obras',
    'DIRECCIÓN GENERAL DE DESARROLLO SOCIAL': 'Desarrollo Social',
    'DIRECCIÓN GENERAL JURÍDICA Y SERVICIOS LEGALES': 'Jurídico',
    'DIRECCIÓN GENERAL DE ADMINISTRACIÓN': 'Administración',
    'DIRECCIÓN GENERAL DE PARTICIPACIÓN CIUDADANA': 'Participación Ciudadana',
}
# cómo se llama cada columna en las hojas que ya llegan en layout
# la columna donde cada hoja guarda lo que de verdad hizo. Se llama distinto en
# cada una y viene a un nivel más fino que el catálogo: ZUMBA, CORTE, PSICOLOGÍA
# son ACTIVIDADES; el servicio sale de mapearlas (ver arbol_servicios.py).
ACTIVIDAD = ('TIPO DE SERVICIO', 'ASUNTO', 'GESTIÓN', 'GESTION', 'TIPO DE ASESORÍA',
             'TIPO DE ASESORIA', 'SERVICIO OFRECIDO', 'MOTIVO', 'APOYO', 'ACTIVIDAD',
             'EVENTO')
# eventos de Desarrollo Social que en realidad son de Género (Tarjeta Violeta,
# Jornada Azul) — el manual dice que ese servicio es de la propia Dirección de
# Género, no de Desarrollo Social, aunque la lista semanal los junte
GENERO_DESDE_DS = re.compile(r'VIOLETA|JORNAND?A\s*AZUL', re.I)
# FUERA DE ALCANCE: "Jornada Azul" (lista de Desarrollo Social, 414 filas, todas 2025-10-17) fue una
# activación política de partido, no un servicio de gobierno. Se EXCLUYE de la base única por
# instrucción del usuario (29-oct-2026), vigente hasta que la dependencia deje de enviarla.
# No se mueve a otra dependencia ni se cuenta como solicitud. FUERA_ALCANCE_ESPERADAS es la cifra
# conocida: si un corte trae otra, el corte lo avisa en las notas.
FUERA_ALCANCE = re.compile(r'JORNAND?A\s*AZUL', re.I)
FUERA_ALCANCE_ESPERADAS = 414

ALIAS = {
    'nombre': ('NOMBRE', 'NOMBRES', 'NOMBRE(S)', 'NOMBRE (S)'), 'apellido_paterno': ('APELLIDOP', 'APELLIDO PATERNO', 'PATERNO'),
    'ApellidoM': ('APELLIDOM', 'APELLIDO MATERNO', 'MATERNO'), 'Sexo': ('SEXO', 'GENERO'),
    'Teléfono': ('TELEFONO', 'TEL'), 'colonia': ('COLONIA',), 'Territorial': ('TERRITORIAL',),
    'seccion': ('SECCION',), 'calle': ('CALLE',), 'numero': ('NO.', 'NUMERO', 'NUM'),
    'Nacimiento': ('NACIMIENTO', 'FECHA DE NACIMIENTO'), 'CURP': ('CURP',),
    'Nacionalidad': ('NACIONALIDAD',), 'fecha': ('FECHA',), 'lat': ('LATITUD', 'LAT'),
    'lng': ('LONGITUD', 'LNG', 'LON'), 'observaciones': ('OBSERVACIONES', 'TEMA/HIPOTESIS', 'TEMA'),
    'servicio': ('SERVICIO OFRECIDO', 'SERVICIO'), 'Folio': ('FOLIO',),
}
VACIOS = r'S\s*/?\s*D|S\s*/?\s*N|N\s*/?\s*A|N\s*/?\s*D|SIN\s+DATO|SIN\s+APELLIDO|SIN\s+NOMBRE'
MESES = {'ENERO': 1, 'FEBRERO': 2, 'MARZO': 3, 'ABRIL': 4, 'MAYO': 5, 'JUNIO': 6,
         'JULIO': 7, 'AGOSTO': 8, 'SEPTIEMBRE': 9, 'OCTUBRE': 10, 'NOVIEMBRE': 11,
         'DICIEMBRE': 12}
# ninguna atención de esta administración cae fuera de esta ventana: lo que se
# sale es basura de captura (seriales mal leídos, teléfonos en la columna fecha).
# La administración arrancó el 1-oct-2024; el tope es el propio corte, nunca el
# futuro — 172 filas con "citas" hasta oct-2027 resultaron ser error de captura,
# no fechas programadas (21-ago-2026).
VENTANA_DESDE = '2024-10-01'
# nombres de pestaña que no dicen nada del servicio: la hoja se llama así porque
# el área mandó su base completa, no una línea de atención
SIN_SERVICIO = {'CONCENTRADO', 'SHEET1', 'HOJA 1', 'HOJA1', 'HOJA2', 'D',
                'BLANKSPACE', 'BASE', 'GENERAL', 'BASE GENERAL'}
BASURA = {'DS_D', 'JUR_Hoja1'}          # sin una sola fila con persona
# DS_Hoja1 no tiene encabezado y trae 38 filas reales entre 1,008: el nombre
# vive en las columnas 3-5 y la calle en la 7. Se lee por posición, a propósito.
# La 6a JUNTA no trae encabezado en ninguna fila: los datos arrancan en la 4 y
# la columna 5 es la fecha de NACIMIENTO (clase 2007, conscriptos), no la de
# atención. Leerla como fecha de atención metía 1,094 atenciones en 2007.
POSICIONAL = {
    'DS_Hoja1': {'nombre': 3, 'apellido_paterno': 4, 'ApellidoM': 5, 'calle': 7},
    'JUR_6a. JUNTA': {'nombre': 0, 'apellido_paterno': 1, 'ApellidoM': 2, 'Sexo': 3,
                      'Nacimiento': 5, 'colonia': 6},
}


def sa(s):
    s = unicodedata.normalize('NFD', str(s if s is not None else ''))
    return ''.join(c for c in s if unicodedata.category(c) != 'Mn')


def limpia(v):
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return ''
    s = str(v).strip()
    return '' if s.lower() in ('nan', 'nat', 'none', '-', '.') else s


def texto(v):
    """Texto de persona: sin placeholders pegados, sin dobles espacios."""
    s = limpia(v)
    if not s:
        return ''
    s = re.sub(rf'(?i)(?<=\s)({VACIOS})(?=\s|$)', ' ', f' {s} ')
    s = re.sub(rf'(?i)^\s*({VACIOS})\s*$', '', s)
    return ' '.join(s.split())


def tel10(v):
    s = re.sub(r'\D', '', limpia(v).replace('.0', ''))
    if len(s) > 10 and s.startswith(('52', '1')):
        s = s[-10:]
    return s if len(s) == 10 else ''


def fecha_norm(v, ventana=True):
    """`ventana` acota a fechas de atención plausibles. Se apaga para
    Nacimiento, que legítimamente cae fuera (conscriptos clase 2007)."""
    def ok(d):
        # tope de la ventana = CORTE ACTUAL del módulo, no el de cuando se
        # importó — los scripts de corte solo reasignan bu.CORTE, así que el
        # tope tiene que leerse en cada llamada o se queda pegado al corte
        # con el que se escribió este archivo (bug real: se quedó en
        # 2026-08-13 durante 3 cortes, 01/11/25-sep, tapando toda fecha
        # posterior).
        return d if not ventana or VENTANA_DESDE <= d <= CORTE else ''
    if isinstance(v, (datetime, date)):
        return ok(v.strftime('%Y-%m-%d'))
    s = limpia(v)
    if not s:
        return ''
    if re.fullmatch(r'\d{5}', s):                     # serial de Excel
        return ok((datetime(1899, 12, 30) + pd.Timedelta(days=int(s))).strftime('%Y-%m-%d'))
    m = re.search(r'(\d{1,2})\s*DE\s*([A-ZÁÉÍÓÚ]+)\s*(?:DE\s*)?(\d{4})', sa(s).upper())
    if m and sa(m.group(2)) in MESES:
        return ok(f'{int(m.group(3)):04d}-{MESES[sa(m.group(2))]:02d}-{int(m.group(1)):02d}')
    # el día va primero (formato mexicano). Poner %m/%d antes convertía
    # 05/08/2026 en 8 de mayo y producía fechas imposibles.
    for f in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d', '%d/%m/%Y', '%d/%m/%y',
              '%d-%m-%Y', '%Y/%m/%d', '%m/%d/%Y'):
        try:
            d = datetime.strptime(s.split(',')[0].split('.')[0].strip(), f)
        except ValueError:
            continue
        return ok(d.strftime('%Y-%m-%d'))
    return ''


def coord(v):
    s = limpia(v).replace(',', '.')
    try:
        f = float(s)
    except ValueError:
        return ''
    return f'{f:.6f}' if -180 < f < 180 and f != 0 else ''    # 6 decimales: ~10 cm


def esquema(rows, dic):
    """H/M o F/M — se decide POR HOJA y se VALIDA contra los nombres.

    Es la trampa más cara de estas bases: la M significa Mujer en las hojas H/M
    y Hombre en las F/M, y ambas conviven en el mismo libro. Basta una H suelta
    entre miles de filas para que la regla "si hay H es H/M" voltee una hoja
    entera. Por eso se prueban las dos hipótesis contra el diccionario de
    primeros nombres del padrón y gana la que concuerde más.
    """
    letras = collections.Counter(r['_sexo'] for r in rows if r['_sexo'] in 'HMF' and r['_sexo'])
    if not letras:
        return 'HM'
    if 'F' not in letras:
        return 'HM'
    if 'H' not in letras:
        return 'FM'
    aciertos = {'HM': 0, 'FM': 0}
    for r in rows:
        pn = sa(r['nombre']).upper().split()
        if not pn or pn[0] not in dic or r['_sexo'] not in 'HMF':
            continue
        for esq in ('HM', 'FM'):
            if sexo_norm(r['_sexo'], r['CURP'], esq) == dic[pn[0]]:
                aciertos[esq] += 1
    return 'FM' if aciertos['FM'] > aciertos['HM'] else 'HM'


def sexo_norm(v, curp='', esq='HM', dic=None):
    """CURP > palabra completa > letra según el esquema de la hoja > nombre."""
    c = limpia(curp).upper()
    if len(c) >= 11 and c[10] in 'HM':
        return 'Hombre' if c[10] == 'H' else 'Mujer'
    s = sa(limpia(v)).upper().strip()
    if s.startswith(('FEM', 'MUJ')):
        return 'Mujer'
    if s.startswith(('MASC', 'HOM')) or s in ('MACULINO', 'MASCULNO'):
        return 'Hombre'
    if s == 'H':
        return 'Hombre'
    if s == 'F':
        return 'Mujer'
    if s == 'M':
        if esq == 'HM':
            return 'Mujer'
        if esq == 'FM':
            return 'Hombre'
    return ''


def dic_nombres():
    """primer nombre -> sexo (diccionario de nombres incluido en Nebula; solo nombres de pila, sin datos personales)."""
    import json as _j
    ruta = os.path.join(BASE, 'catalogo', 'nombres_sexo.json')
    return _j.load(open(ruta, encoding='utf-8')) if os.path.exists(ruta) else {}


def folio_sintetico(dep, r):
    """Determinista: misma fila, mismo folio, en cada reconstrucción."""
    firma = '|'.join((sa(r['nombre']).upper(), sa(r['apellido_paterno']).upper(),
                      r['Teléfono'], r['fecha'], sa(r['servicio']).upper()))
    h = hashlib.sha1(firma.encode()).hexdigest()[:10].upper()
    return f'CUH/{sa(dep).upper().replace(" ", "")[:8]}/{h}'


def _idx(cols):
    """columna del layout -> posición en esta hoja."""
    limpio = [sa(c).upper().strip().rstrip('.') for c in cols]
    pos = {}
    for campo, claves in ALIAS.items():
        for i, c in enumerate(limpio):
            if c in [k.rstrip('.') for k in claves]:
                pos[campo] = i
                break
    return pos


def _encabezado(df):
    """La fila del encabezado. Las JUNTAS lo traen hasta la 5 y lo escriben
    NOMBRES, en plural: exigir el singular exacto las mandaba al parser
    posicional, que las leía mal sin avisar."""
    for i in range(min(10, len(df))):
        for c in df.iloc[i].tolist():
            cn = sa(c).upper().strip()
            if cn.startswith('NOMBRE'):
                return i
    return None


DIC = {}


def del_libro(ruta, saltar=('Índice',), prefijo=None):
    """Las pestañas del concentrado semanal. Con `prefijo`, el archivo es una base suelta de un área
    y sus hojas se leen como si fueran PREFIJO_nombre dentro del concentrado."""
    filas, notas = [], []
    excluidas = {}
    for real in xl.hojas(ruta):
        hoja = f'{prefijo}_{real}' if prefijo else real
        if hoja in saltar or hoja in BASURA:
            if hoja in BASURA:
                notas.append((hoja, 'omitida: sin filas con persona'))
            continue
        crudo = xl.hoja(ruta, real)
        if crudo.empty:
            notas.append((hoja, 'vacía'))
            continue
        dep = DEPS.get(hoja.split('_')[0], hoja.split('_')[0])
        pestana = hoja.split('_', 1)[1] if '_' in hoja else hoja
        # el catálogo manda: la pestaña solo dice de dónde salió la fila
        servicio = arb.por_pestana(dep, pestana) or pestana
        if servicio == pestana and sa(servicio).upper().strip() in SIN_SERVICIO:
            servicio = f'{dep} — gestión general'
        if hoja in POSICIONAL:
            for _, f in crudo.iterrows():
                v = f.tolist()
                g = lambda k: v[POSICIONAL[hoja][k]] if k in POSICIONAL[hoja] else None
                r = _fila(g, dep, servicio, hoja)
                if r:
                    filas.append(r)
            continue
        hi = _encabezado(crudo)
        if hi is None:
            filas += _sin_encabezado(crudo, dep, servicio, hoja, notas)
            continue
        pos = _idx(crudo.iloc[hi].tolist())
        limpio = [sa(c).upper().strip() for c in crudo.iloc[hi].tolist()]
        i_act = next((k for k, c in enumerate(limpio) if c in ACTIVIDAD), None)
        dela = []
        for _, f in crudo.iloc[hi + 1:].iterrows():
            v = f.tolist()
            g = lambda k: v[pos[k]] if k in pos and pos[k] < len(v) else None
            r = _fila(g, dep, servicio, hoja)
            if r:
                # el servicio lo decide la actividad; la pestaña es la sede
                act = limpia(v[i_act]) if i_act is not None and i_act < len(v) else ''
                if FUERA_ALCANCE.search(sa(act)):
                    excluidas[hoja] = excluidas.get(hoja, 0) + 1
                    continue
                dep_efectiva = 'Genero' if dep == 'Desarrollo Social' and GENERO_DESDE_DS.search(sa(act)) else dep
                serv = arb.clasifica(dep_efectiva, act)[0] if act else None
                if serv:
                    r['Dependencia'] = dep_efectiva
                if serv:                      # la actividad afina el servicio
                    r['servicio'] = serv
                if act and not r['observaciones']:
                    r['observaciones'] = f'{act} · sede {pestana}'
                # varias hojas (Obras, ...) no traen columna de actividad propia:
                # el dato real llega ya mapeado a "observaciones" por ALIAS. Si la
                # actividad no dio servicio, se intenta clasificar con eso.
                if not serv and r['observaciones']:
                    serv2 = arb.clasifica(dep_efectiva, r['observaciones'])[0]
                    if serv2:
                        r['servicio'] = serv2
                dela.append(r)
        esq = esquema(dela, DIC)
        for x in dela:
            x['Sexo'] = sexo_norm(x['_sexo'], x['CURP'], esq)
        filas += dela
    n_ex = sum(excluidas.values())
    if n_ex:
        aviso = '' if n_ex == FUERA_ALCANCE_ESPERADAS else f' ¡OJO! la cifra conocida es {FUERA_ALCANCE_ESPERADAS}: revisar si hay filas nuevas o faltan'
        notas.append(('Jornada Azul (EXCLUIDA)', f'{n_ex} filas excluidas {excluidas}: activación política, no es servicio de gobierno; regla vigente hasta nueva instrucción.{aviso}'))
    return filas, notas


def _sin_encabezado(crudo, dep, servicio, hoja, notas):
    """JUR_ASESORÍAS y las JUNTAS: layout posicional, y mezclado."""
    out = []
    for _, f in crudo.iterrows():
        v = [limpia(x) for x in f.tolist()]
        if len(v) < 7:
            continue
        if fecha_norm(v[5]):            # layout viejo: sin nombre de pila
            nom, ap, am, tel, fch, col = '', v[1], v[2], v[4], v[5], v[6]
        elif len(v) > 6 and fecha_norm(v[6]):
            nom, ap, am, tel, fch, col = v[1], v[2], v[3], v[5], v[6], v[7] if len(v) > 7 else ''
        else:
            continue
        g = {'nombre': nom, 'apellido_paterno': ap, 'ApellidoM': am,
             'Teléfono': tel, 'fecha': fch, 'colonia': col}.get
        r = _fila(g, dep, servicio, hoja)
        if r:
            out.append(r)
    if not out:
        notas.append((hoja, 'sin encabezado y sin filas legibles'))
    return out


def _fila(g, dep, servicio, hoja='', **fijos):
    r = {c: '' for c in LAYOUT}
    r['nombre'] = texto(g('nombre'))
    r['apellido_paterno'] = texto(g('apellido_paterno'))
    r['ApellidoM'] = texto(g('ApellidoM'))
    r['CURP'] = limpia(g('CURP')).upper()
    r['_sexo'] = sa(limpia(g('Sexo'))).upper().strip()
    r['Teléfono'] = tel10(g('Teléfono'))
    r['colonia'] = limpia(g('colonia')).upper()
    r['Territorial'] = limpia(g('Territorial')).upper()
    r['seccion'] = re.sub(r'\D', '', limpia(g('seccion')))
    r['calle'] = limpia(g('calle'))
    r['numero'] = limpia(g('numero')).replace('.0', '')
    r['Nacimiento'] = fecha_norm(g('Nacimiento'), ventana=False)
    r['Nacionalidad'] = limpia(g('Nacionalidad'))
    r['fecha'] = fecha_norm(g('fecha'))
    r['lat'] = coord(g('lat'))
    r['lng'] = coord(g('lng'))
    r['observaciones'] = limpia(g('observaciones'))
    if hoja.startswith('JUR_') and 'JUNTA' in hoja.upper():      # cada fila conserva su junta (decisión 30-oct)
        junta = re.sub(r'\s*°', '°', hoja.split('_', 1)[1]).strip()
        r['observaciones'] = f"{junta} · {r['observaciones']}" if r['observaciones'] else junta
    r['Dependencia'] = dep
    r['servicio'] = limpia(g('servicio')) or servicio
    r['Folio'] = limpia(g('Folio'))
    r.update(fijos)
    if not (r['nombre'] or r['apellido_paterno'] or r['Teléfono'] or r['Folio']):
        return None                     # ni persona ni folio: no es un registro
    if not (r['lat'] and r['lng']):     # media coordenada apunta a ningún lado
        r['lat'] = r['lng'] = ''
    # varias hojas usan como «Folio» un contador de fila que arranca en 1: eso
    # no es folio, es número de renglón, y choca entre hojas y con el del SUAC.
    # Se califica con su origen para volverlo único sin perder el número.
    if hoja and re.fullmatch(r'\d{1,6}', r['Folio']):
        r['Folio'] = f"{sa(hoja).upper().replace(' ', '')[:16]}/{r['Folio']}"
    if not r['Folio']:
        r['Folio'] = folio_sintetico(dep, r)
    return r


def del_suac(ruta):
    """La única fuente que no llega en layout: se traduce."""
    import openpyxl
    wb = openpyxl.load_workbook(ruta, read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    it = ws.iter_rows(values_only=True)
    hdr = next(it)
    ix = {h: k for k, h in enumerate(hdr) if h}
    C = lambda k: ix.get(k)
    filas = []
    for v in it:
        if v[C('SUAC')] is None and v[C('Nombre')] is None:
            continue
        area = limpia(v[C('ÁREA ADMINISTRATIVA')])
        terr = area.replace('COORDINACIÓN TERRITORIAL ', '') if area.startswith('COORDINACIÓN TERRITORIAL') else ''
        dep = 'Participación Ciudadana' if terr else AREA_SUAC.get(area, area)
        if dep in ('#N/A', '(vacío)'):
            dep = ''
        g = {'nombre': v[C('Nombre')], 'apellido_paterno': v[C('Apellido Paterno')],
             'ApellidoM': v[C('Apellido Materno')], 'colonia': v[C('COLONIA SERVICIO')],
             'calle': v[C('CALLE')], 'numero': v[C('Número')],
             'fecha': v[C('FECHA DE INGRESO')],
             'observaciones': v[C('DESCRIPCIÓN DEL SERVICIO')],
             'servicio': v[C('SERVICIOS (CATALOGO NUEVO)')],
             'Folio': v[C('SUAC')], 'Territorial': terr}.get
        r = _fila(g, dep, limpia(v[C('SERVICIOS (CATALOGO NUEVO)')]))
        if r:
            filas.append(r)
    return filas


def de_amazonica(ruta):
    """El bot de WhatsApp: ya llega en layout, en la hoja BlankSpace."""
    d = xl.hoja(ruta, 'BlankSpace')
    hi = _encabezado(d)
    if hi is None:
        return []
    pos = _idx(d.iloc[hi].tolist())
    filas = []
    for _, f in d.iloc[hi + 1:].iterrows():
        v = f.tolist()
        g = lambda k: v[pos[k]] if k in pos and pos[k] < len(v) else None
        r = _fila(g, 'Amazónica', limpia(g('servicio')) or 'Reporte ciudadano WhatsApp')
        if r:
            filas.append(r)
    return filas


def main():
    global DIC
    DIC = dic_nombres()
    print(f'diccionario de nombres del padrón: {len(DIC):,} nombres')
    print('leyendo el concentrado de las dependencias…')
    libro, notas = del_libro(LIBRO)
    print(f'  {len(libro):,} registros')
    print('leyendo el SUAC…')
    suac = del_suac(SUAC)
    print(f'  {len(suac):,} registros')
    print('leyendo Amazónica…')
    amz = de_amazonica(AMZ)
    print(f'  {len(amz):,} registros')

    filas = libro + suac + amz
    dic = dic_nombres()
    n_dic = 0
    for r in filas:
        if not r.get('Sexo'):
            r['Sexo'] = sexo_norm(r.get('_sexo', ''), r['CURP'])
        if not r['Sexo'] and dic:
            pn = sa(r['nombre']).upper().split()
            if pn and pn[0] in dic:
                r['Sexo'] = dic[pn[0]]
                n_dic += 1
    print(f'  sexo inferido por nombre: {n_dic:,} (diccionario de {len(dic):,} nombres del padrón)')
    os.makedirs(OUT, exist_ok=True)
    ruta = os.path.join(OUT, f'BASE_UNICA_{CORTE}.csv')
    with open(ruta, 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=LAYOUT)
        w.writeheader()
        for r in filas:
            w.writerow({c: r.get(c, '') for c in LAYOUT})

    try:                                  # el equipo trabaja en Excel
        import openpyxl
        from openpyxl.styles import Font
        from openpyxl.utils import get_column_letter
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = 'Base única'
        ws.append(LAYOUT)
        for c in ws[1]:
            c.font = Font(bold=True)
        for r in filas:
            ws.append([r.get(c, '') for c in LAYOUT])
        ws.freeze_panes = 'A2'
        for k, c in enumerate(LAYOUT, 1):
            ws.column_dimensions[get_column_letter(k)].width = {
                'nombre': 22, 'apellido_paterno': 18, 'ApellidoM': 18, 'colonia': 24,
                'calle': 26, 'observaciones': 44, 'servicio': 34, 'Folio': 22,
                'Dependencia': 20, 'Territorial': 22}.get(c, 12)
        wb.save(os.path.join(OUT, f'BASE_UNICA_{CORTE}.xlsx'))
    except ImportError:
        pass

    fol = collections.Counter(r['Folio'] for r in filas)
    sint = [r for r in filas if r['Folio'].startswith('CUH/')]
    fech = [r['fecha'] for r in filas if r['fecha']]
    with open(os.path.join(OUT, 'AUDITORIA.md'), 'w', encoding='utf-8') as fh:
        fh.write(f'# Base única · corte {CORTE}\n\n'
                 f'**{len(filas):,} registros · {len(LAYOUT)} columnas.** '
                 f'Un solo layout para las tres fuentes.\n\n'
                 f'| fuente | registros |\n|---|---:|\n'
                 f'| concentrado de dependencias (106 pestañas) | {len(libro):,} |\n'
                 f'| SUAC | {len(suac):,} |\n| Amazónica | {len(amz):,} |\n\n'
                 f'## Llave\n\n'
                 f'- folios distintos: **{len(fol):,}**\n'
                 f'- folios que se repiten: **{sum(1 for n in fol.values() if n > 1):,}** '
                 f'— el Folio NO es llave primaria: un folio del SUAC genera varias '
                 f'órdenes de trabajo y cada una es una fila\n'
                 f'- folios sintetizados (la fuente no traía): **{len(sint):,}** '
                 f'({100*len(sint)/len(filas):.0f}%), deterministas por firma\n\n'
                 f'## Cobertura\n\n| columna | con dato | % |\n|---|---:|---:|\n')
        for c in LAYOUT:
            n = sum(1 for r in filas if r.get(c))
            fh.write(f'| {c} | {n:,} | {100*n/len(filas):.1f}% |\n')
        fh.write(f'\n## Rangos\n\n- fecha de atención: {min(fech)} → {max(fech)} '
                 f'({len(fech):,} con dato)\n')
        if notas:
            fh.write('\n## Hojas no cargadas\n\n')
            for h, por in notas:
                fh.write(f'- **{h}** — {por}\n')
    print(f'\n{len(filas):,} registros · {len(LAYOUT)} columnas → {ruta}')
    dep = collections.Counter(r['Dependencia'] for r in filas)
    print('\npor dependencia:')
    for d, n in dep.most_common():
        print(f'   {n:7,}  {d}')
    print('\ncobertura por columna:')
    for c in LAYOUT:
        n = sum(1 for r in filas if r.get(c))
        print(f'   {c:20s} {n:7,}  {100*n/len(filas):5.1f}%')
    if notas:
        print('\nhojas no cargadas:')
        for h, por in notas:
            print(f'   · {h}: {por}')
    return filas


if __name__ == '__main__':
    main()

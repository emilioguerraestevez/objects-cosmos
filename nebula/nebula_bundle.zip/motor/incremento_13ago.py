#!/usr/bin/env python3
"""Incremento del corte 13-ago-2026 contra el libro del 7-ago.

Compara el libro unificado nuevo contra el del 24-jul (auditado en su momento
celda a celda contra los siete originales) y aísla lo que llegó nuevo. Servicios
Urbanos no venía en el libro anterior, así que su base de comparación es el
archivo suelto de la DGSU.

TRAMPAS QUE YA COSTARON CARO Y AQUÍ ESTÁN CUBIERTAS
  · El tipo del teléfono cambia entre cortes: un mismo número llega '5545663951'
    en un corte y '5545663951.0' en el siguiente. Sin canonizar antes de firmar,
    el diff explota (en un corte anterior Obras marcó 2,641 nuevas en vez de 445).
  · Fechas en texto: '07 DE ENERO 2026' (Género) y '1/09/2025' (Obras).
  · DS-Hoja 1 trae el encabezado en la TERCERA fila, bajo dos filas de títulos
    de grupo.
  · SL-ASESORÍAS no tiene encabezado y mezcla dos layouts: las filas viejas no
    traen nombre de pila (apellido paterno en la primera columna) y las recientes
    recorren una columna. Se detecta fila por fila.
  · DS-Hoja1 es hoja basura: 1,008 filas de las que solo ~38 son reales.
  · El Índice del libro infla los conteos (dice 882 en Lactario, hay 134): se
    cuenta por cuenta propia, nunca por el Índice.
  · La firma estable es nombre+teléfono+fecha, NUNCA la fila completa: un
    reordenamiento de columnas marcaría todo como nuevo.
"""
import os
import re
import unicodedata
from datetime import datetime

import pandas as pd

DESCARGAS = os.path.expanduser('~/Downloads')
NUEVO = os.path.join(DESCARGAS, 'drive-download-20260817T051938Z-1-001/BDDConcentrado_General_Unificado_13ago.xlsx')
PREVIO = os.path.join(DESCARGAS, 'BDDConcentrado_General_Unificado_7ago.xlsx')
SU_PREVIO = os.path.join(DESCARGAS, 'SEPT25 AL 20-JUL-26 DGSU BASES GENERALES.xlsx')

# prefijo de pestaña -> dependencia, en los dos libros
DEPS = {'DS': 'Desarrollo Social', 'DGDS': 'Desarrollo Social',
        'EC': 'Cultura', 'CONC': 'Cultura',
        'EG': 'Genero', 'DEEGeIS': 'Genero',
        'SL': 'Jurídico', 'AyM': 'Jurídico',
        'SU': 'Servicios Urbanos', 'DGSU': 'Servicios Urbanos',
        'SC': 'Seguridad',
        'OU': 'Obras', 'DGODU': 'Obras'}

MESES = {'ENERO': 1, 'FEBRERO': 2, 'MARZO': 3, 'ABRIL': 4, 'MAYO': 5, 'JUNIO': 6,
         'JULIO': 7, 'AGOSTO': 8, 'SEPTIEMBRE': 9, 'OCTUBRE': 10,
         'NOVIEMBRE': 11, 'DICIEMBRE': 12}


def sin_acentos(s):
    s = unicodedata.normalize('NFD', str(s or ''))
    return ''.join(c for c in s if unicodedata.category(c) != 'Mn')


# marcas de "aquí no hubo dato" que la captura deja en el campo del nombre. Si
# no se quitan ANTES de normalizar, "GUADALUPE MAYA S/D" no empata con
# "Guadalupe Maya" del padrón y la persona entra como alta falsa.
VACIOS = r'S\s*/?\s*D|S\s*/?\s*N|N\s*/?\s*A|N\s*/?\s*D|SIN\s+DATO|SIN\s+APELLIDO'


def norm_nombre(*partes):
    t = ' '.join(str(p) for p in partes if p is not None and str(p).lower() != 'nan')
    t = sin_acentos(t).upper()
    t = re.sub(r'"[^"]*"|\bXX+\b', ' ', t)
    # lookarounds, no \s: consumir el espacio dejaría vivo el segundo placeholder
    # cuando vienen pegados ("JESSICA ALEJANDRA S/D S/D", paterno y materno vacíos)
    t = re.sub(rf'(?<![A-Z])(?:{VACIOS})(?![A-Z])', ' ', t)
    t = re.sub(r'[^A-Z ]', ' ', t)
    return ' '.join(t.split())


def tel10(x):
    """Canoniza el teléfono ANTES de firmar: quita el .0 del float, la notación
    científica y los prefijos 52/1. Si no quedan diez dígitos, no hay teléfono."""
    s = str(x or '').strip()
    if s.lower() in ('nan', 'none', ''):
        return ''
    if re.fullmatch(r'\d+\.0+', s):
        s = s[:s.index('.')]
    if 'e+' in s.lower():
        try:
            s = f'{float(s):.0f}'
        except ValueError:
            pass
    d = re.sub(r'\D', '', s)
    for pre in ('521', '52', '1'):
        if len(d) == 10 + len(pre) and d.startswith(pre):
            d = d[len(pre):]
    return d if len(d) == 10 and d[0] not in '01' else ''


EPOCA = datetime(1899, 12, 30)      # el cero de Excel


def fecha_norm(x):
    """A ISO o a vacío. Nunca devuelve el texto crudo: una fecha que no se
    entiende y se deja pasar tal cual entra a la firma con la ortografía del
    corte, y el mismo registro se marca nuevo cada semana."""
    if x is None or (isinstance(x, float) and pd.isna(x)):
        return ''
    if isinstance(x, (datetime, pd.Timestamp)):
        return x.strftime('%Y-%m-%d')
    s = str(x).strip()
    if s.lower() in ('nan', 'nat', ''):
        return ''

    # serial de Excel: la celda perdió el formato de fecha en algún guardado
    if re.fullmatch(r'\d{5}(\.\d+)?', s) and 20000 <= float(s) <= 60000:
        return (EPOCA + pd.Timedelta(days=float(s))).strftime('%Y-%m-%d')

    t = sin_acentos(s).upper()
    t = re.sub(r'^(LUNES|MARTES|MIERCOLES|JUEVES|VIERNES|SABADO|DOMINGO)\s*,?\s*',
               '', t)                                   # "jueves, 16 de julio…"
    m = re.match(r'^(\d{1,2})\s+DE\s+([A-Z]+)\s+(?:DE(?:L)?\s+)?(\d{4})', t)
    if m and m.group(2) in MESES:
        return f'{m.group(3)}-{MESES[m.group(2)]:02d}-{int(m.group(1)):02d}'
    for f in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d', '%d/%m/%Y', '%d/%m/%y',
              '%d-%m-%Y', '%m/%d/%Y'):
        try:
            return datetime.strptime(s.split('.')[0].strip(), f).strftime('%Y-%m-%d')
        except ValueError:
            pass
    return ''       # ilegible (teléfonos corridos de columna, texto suelto)


def dependencia(hoja):
    return DEPS.get(hoja.split('-')[0], hoja.split('-')[0])


def _fila_encabezado(df):
    """Devuelve el índice de la fila que trae los nombres de columna."""
    for i in range(min(5, len(df))):
        celdas = [sin_acentos(c).upper().strip() for c in df.iloc[i].tolist()]
        if any(c in ('NOMBRE', 'NOMBRE(S)') for c in celdas):
            return i
    return None


def _col(cols, *claves):
    for i, c in enumerate(cols):
        cn = sin_acentos(c).upper().strip()
        if any(cn == k or cn.startswith(k) for k in claves):
            return i
    return None


def extrae_hoja(ruta, hoja):
    """Un registro por fila útil: (dependencia, hoja, nombre, tel, fecha, colonia)."""
    crudo = pd.read_excel(ruta, sheet_name=hoja, header=None)
    if crudo.empty:
        return []
    dep = dependencia(hoja)
    out = []
    hi = _fila_encabezado(crudo)

    if hi is None:                      # sin encabezado: layout posicional
        for _, f in crudo.iterrows():
            v = f.tolist()
            # SL-ASESORÍAS: dos layouts. Si la col 5 trae fecha, las viejas
            # (apellidoP en col1, sin nombre de pila); si no, todo corrido uno.
            if fecha_norm(v[5] if len(v) > 5 else None):
                nom, tel, fch, col = norm_nombre(v[1], v[2]), tel10(v[4]), fecha_norm(v[5]), v[6]
            elif len(v) > 6 and fecha_norm(v[6]):
                nom, tel, fch, col = norm_nombre(v[1], v[2], v[3]), tel10(v[5]), fecha_norm(v[6]), v[7]
            elif tel10(v[4] if len(v) > 4 else None):
                # fecha rota de captura ('19/3/236'): la persona existe igual
                nom, tel, fch, col = norm_nombre(v[1], v[2]), tel10(v[4]), '', v[6]
            else:
                continue        # separador de mes (' SEPTIEMBRE  2025') o fila vacía
            if nom or tel:
                out.append((dep, hoja, nom, tel, fch, str(col or '').strip()))
        return out

    cols = crudo.iloc[hi].tolist()
    d = crudo.iloc[hi + 1:]
    i_nom = _col(cols, 'NOMBRE')
    i_ap = _col(cols, 'APELLIDOP', 'APELLIDO P', 'PATERNO')
    i_am = _col(cols, 'APELLIDOM', 'APELLIDO M', 'MATERNO')
    i_tel = _col(cols, 'TELEFONO', 'TELEFONO 1', 'TEL')
    i_fch = _col(cols, 'FECHA')
    i_col = _col(cols, 'COLONIA')
    for _, f in d.iterrows():
        v = f.tolist()
        g = lambda i: v[i] if i is not None and i < len(v) else None
        nom = norm_nombre(g(i_nom), g(i_ap), g(i_am))
        tel = tel10(g(i_tel))
        if not nom and not tel:
            continue
        out.append((dep, hoja, nom, tel, fecha_norm(g(i_fch)),
                    str(g(i_col) or '').strip()))
    return out


def extrae_libro(ruta, saltar=()):
    reg = []
    for hoja in pd.ExcelFile(ruta).sheet_names:
        if hoja == 'Índice' or hoja in saltar:
            continue
        reg += extrae_hoja(ruta, hoja)
    return reg


def firma(r):
    """nombre + teléfono + fecha. Nunca la fila completa."""
    return (r[2], r[3], r[4])


if __name__ == '__main__':
    print('leyendo el corte nuevo (31-jul)…')
    nuevo = extrae_libro(NUEVO)
    print('leyendo el corte previo (24-jul)…')
    previo = extrae_libro(PREVIO)
    print('leyendo Servicios Urbanos previo (suelto, 20-jul)…')
    su_prev = []
    for hoja in pd.ExcelFile(SU_PREVIO).sheet_names:
        su_prev += [('Servicios Urbanos',) + r[1:] for r in extrae_hoja(SU_PREVIO, hoja)]

    print(f'\nregistros útiles: nuevo {len(nuevo):,} · previo {len(previo):,} '
          f'+ DGSU {len(su_prev):,}')
    vistos = {firma(r) for r in previo} | {firma(r) for r in su_prev}
    inc = [r for r in nuevo if firma(r) not in vistos]
    print(f'INCREMENTO: {len(inc):,} registros nuevos\n')
    import collections
    for dep, n in collections.Counter(r[0] for r in inc).most_common():
        tot = sum(1 for r in nuevo if r[0] == dep)
        print(f'  {dep:20} {n:6,} nuevos   de {tot:6,} en el corte')

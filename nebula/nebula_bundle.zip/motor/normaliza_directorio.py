#!/usr/bin/env python3
"""PASO 2 · lleva Dependencia y servicio de la base única al Directorio.

Directorio = catalogo/DEPENDENCIAS_SERVICIOS_CORREGIDO.csv (231 servicios, 11
dependencias). Regla del Directorio: el dueño del servicio es quien tiene la
facultad según el manual, no quien lo captura. El puente viejo→nuevo es
catalogo/CROSSWALK_SERVICIO_VIEJO_NUEVO.csv (corte 15-oct), que se aplica tal cual.
Amazónica es un CANAL: sus filas se reclasifican por el texto del reporte.

Columnas que se agregan al final de las 20 del contrato:
  Canal · Naturaleza · dependencia_origen · servicio_origen
"""
import csv, re, unicodedata, collections, os
CAT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'catalogo')


def sa(s):
    return ''.join(c for c in unicodedata.normalize('NFD', str(s or '')) if unicodedata.category(c) != 'Mn').upper().strip()


def carga():
    dire = list(csv.DictReader(open(os.path.join(CAT, 'DEPENDENCIAS_SERVICIOS_CORREGIDO.csv'), encoding='utf-8-sig')))
    cw = list(csv.DictReader(open(os.path.join(CAT, 'CROSSWALK_SERVICIO_VIEJO_NUEVO.csv'), encoding='utf-8-sig')))
    nat = {(sa(x['dependencia']), sa(x['servicio'])): x['naturaleza'] for x in dire}
    puente = {(sa(x['dependencia_base_unica']), sa(x['servicio_base_unica'])): (x['dependencia_directorio'], x['servicio_directorio']) for x in cw}
    return dire, nat, puente


# Participación Ciudadana · "Puerta a puerta DGG" (hoja PCIU, nueva en el 25-oct)
EXTRA = {
    ('PARTICIPACION CIUDADANA', 'PUERTA A PUERTA DGG'): ('Dir. de Participacion Ciudadana', 'Primer contacto ciudadano en colonia'),
    ('JURIDICO', sa('Cartillas militares – conscriptos (trámite ante SEDENA)')): ('Dir. Juridica y de Legislacion', 'Cartillas militares – conscriptos (trámite ante SEDENA)'),   # juntas de reclutamiento (decisión 30-oct)
    # corte 20-nov: dos registros con servicio nuevo; se asignan al más cercano del Directorio (SUPUESTO, validar)
    ('DESARROLLO SOCIAL', sa('ASESORÍA Y TRÁMITES A LAS COOPERATIVAS')): ('Dir. Gral. de Desarrollo Social', 'Asesoría y cursos de capacitación empresarial'),
    ('SEGURIDAD', sa('ATENCION DE SOLICITUD DE CIERRE DE VIA PUBLICA Y APOYO DE SEGURIDAD EN EVENTOS O ESPECTACULOS REALIZADOS EN VIA PUBLICA')): ('Dir. Gral. de Seguridad Ciudadana', 'Apoyo a eventos en vias publicas en colaboracion de policia auxiliar'),
    ('JURIDICO', sa('Cartillas militares — juntas de reclutamiento')): ('Dir. Juridica y de Legislacion', 'Cartillas militares – conscriptos (trámite ante SEDENA)'),   # mismo servicio, nombre de captura
}
SU = 'Dir. Gral. de Servicios Urbanos'
# Amazónica: por el TEXTO del reporte (el primero que pega). Decisión 19-ago: infraestructura/otro por texto.
AMZ_REGLAS = [
    (r'VEHICULO|AUTO ABANDON|CARRO ABANDON|CHATARR', ('Dir. Gral. de Seguridad Ciudadana', 'Programa de "chatarrización" para vehículos en estado de abandono (enfajillamiento de vehículos')),
    (r'COMERCIO|PUESTO|AMBULANT|VIA PUBLICA.*(INVAD|OBSTRU)|ESTACIONAMIENTO EXCLUSIVO|OBSTACULO', ('Dir. Gral. de Gobierno', 'Asuntos relacionados con el comercio en vía pública')),
    (r'SITUACION DE CALLE|PERSONAS VIVIENDO|CAMPAMENTO', ('Dir. Gral. de Desarrollo Social', 'Atención a población en situación de calle')),
    (r'ARBOL|RAMAS|PODA|TRONCO|DERRIBO', (SU, 'Diagnóstico de sujeto forestal')),
    (r'LUMINARIA|ALUMBRADO|POSTE|FOCO FUNDIDO|SIN LUZ|APAGAD', (SU, 'Reparación de alumbrado público')),
    (r'BACHE|HUNDIMIENTO|HOYO EN (LA )?(CALLE|AVENIDA|ASFALTO)', (SU, 'Bacheo en vialidades secundarias')),
    (r'COLADERA|ALCANTARILLA|TAPA DE REGISTRO|REJILLA|DESAZOLV|DRENAJE|AZOLVE|ENCHARC', (SU, 'Reparación y reposición de tapas de coladera y tapas de registro en vías secundarias')),
    (r'BANQUETA|GUARNICION|ADOQUIN', (SU, 'Reparación de tramo de banquetas frente a domicilio, guarniciones, colocación, retiro y renivelación de adoquín')),
    (r'AGUA|FUGA|HIDRAULIC|SIN AGUA', (SU, 'Mantenimiento a la red de agua potable y servicios hidráulicos')),
    (r'BASURA|TRIQUES|CASCAJO|ESCOMBRO|ANIMAL MUERTO|TIRADERO', (SU, 'Retiro de basura, triques, cascajo o animal muerto en la vía pública')),
    (r'BARRIDO|BARRER|LIMPIA|LIMPIEZA', (SU, 'Solicitud de barrido manual o toque de campana en vía pública')),
    (r'PARQUE|JARDIN|AREA VERDE|PASTO|CESPED', (SU, 'Solicitud de mantenimiento de áreas verdes')),
    (r'PERRO|CANINO|MALTRATO ANIMAL|ANIMALES', (SU, 'Atención canina')),
    (r'MOBILIARIO|BANCA|JUEGOS INFANTILES|BOTE DE BASURA', (SU, 'Mantenimiento de mobiliario urbano del espacio público')),
]
AMZ_CATEGORIA = {  # si el texto no decide, manda la categoría del bot
    'ALUMBRADO': (SU, 'Reparación de alumbrado público'),
    'ARBOLADO': (SU, 'Diagnóstico de sujeto forestal'),
    'LIMPIA': (SU, 'Retiro de basura, triques, cascajo o animal muerto en la vía pública'),
    'PARQUES': (SU, 'Solicitud de mantenimiento de áreas verdes'),
}
DEFAULT_SU = (SU, 'Servicios urbanos – gestiones generales')


def amazonica(r):
    cat = sa(r['servicio'])
    txt = sa(r.get('observaciones', ''))
    for pat, dest in AMZ_REGLAS:
        if re.search(pat, txt):
            return dest, 'texto'
    if cat in AMZ_CATEGORIA:
        return AMZ_CATEGORIA[cat], 'categoría'
    return DEFAULT_SU, 'por defecto'


def reconcilia(dep, srv, dire, validos):
    """Deja (dep, srv) con el nombre EXACTO del Directorio, o None si no existe."""
    if (sa(dep), sa(srv)) in validos:
        return next((x['dependencia'], x['servicio']) for x in dire if (sa(x['dependencia']), sa(x['servicio'])) == (sa(dep), sa(srv)))
    if sa(srv).startswith('REPARACION Y REINSTALACION DE ALUMBRADO'):      # decisión 19-ago: se colapsa la variante
        return SU, 'Reparación de alumbrado público'
    mismos = [x for x in dire if sa(x['servicio']) == sa(srv)]            # mismo servicio, dependencia mal escrita
    if len(mismos) == 1:
        return mismos[0]['dependencia'], mismos[0]['servicio']
    pref = [x for x in dire if sa(x['dependencia']) == sa(dep) and len(sa(srv)) > 40 and sa(x['servicio']).startswith(sa(srv)[:60])]
    if len(pref) == 1:
        return pref[0]['dependencia'], pref[0]['servicio']
    return None


def normaliza(filas):
    dire, nat, puente = carga()
    validos = {(sa(x['dependencia']), sa(x['servicio'])) for x in dire}
    stat = collections.Counter(); sin = collections.Counter(); reglas = collections.Counter(); malos = collections.Counter()
    for r in filas:
        dep0, srv0 = r['Dependencia'], r['servicio']
        k = (sa(dep0), sa(srv0))
        if r.get('_canal') == 'Amazónica':
            (dep, srv), via = amazonica(r); reglas[via] += 1; stat['amazonica'] += 1
        elif sa(srv0) == '#REF!' and sa(dep0) == 'SERVICIOS URBANOS':
            dep, srv = DEFAULT_SU; stat['#REF! (dato roto en origen) → gestiones generales'] += 1
        elif k in puente and puente[k][0]:
            dep, srv = puente[k]; stat['crosswalk'] += 1
        elif k in puente:                      # el crosswalk del 15-oct lo dejó como hueco: se busca por nombre en el Directorio
            dep, srv = dep0, srv0; stat['hueco del crosswalk → por nombre'] += 1
        elif k in EXTRA:
            dep, srv = EXTRA[k]; stat['regla nueva'] += 1
        elif sa(srv0) == '#REF!':
            dep, srv = DEFAULT_SU if sa(dep0) == 'SERVICIOS URBANOS' else (None, None); stat['#REF! → gestiones generales'] += 1
        else:
            dep = srv = None; sin[(dep0, srv0)] += 1
        r['dependencia_origen'], r['servicio_origen'] = dep0, srv0
        if dep:
            rec = reconcilia(dep, srv, dire, validos)
            if rec is None:
                malos[(dep, srv)] += 1; dep = None
            else:
                dep, srv = rec
        if dep:
            r['Dependencia'], r['servicio'] = dep, srv
            r['Naturaleza'] = nat.get((sa(dep), sa(srv)), '')
        else:
            r['Naturaleza'] = ''
        r['Canal'] = r.get('_canal', '')
    return stat, sin, reglas, malos

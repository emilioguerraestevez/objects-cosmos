#!/usr/bin/env python3
"""PADRON_FINAL_02AGO2026 = padrón vigente + altas del 31-jul + Participación.

REGLA QUE NO SE ROMPE: la base aprobada va CONGELADA. No se re-deduplica
base-contra-base — las reglas de colapso encontraban clusters de hasta 8
personas por compartir teléfono y apellido paterno (familias enteras), y el
usuario validó el padrón tal como está. Solo se deduplica entre las CANDIDATAS
nuevas, y cada candidata se compara contra la base para decidir si es alta o no.

IDENTIDAD, el mismo criterio del padrón:
  1. teléfono de diez dígitos igual  → la misma persona (llave fuerte)
  2. sin teléfono, nombre completo normalizado igual → la misma persona
     (llave débil: colapsa homónimos, por eso se cuenta aparte)

    python3 consolida_02ago.py
"""
import collections
import os
import re
import unicodedata

import pandas as pd

import incremento_31jul as inc

BASE = os.path.dirname(os.path.abspath(__file__))
VIGENTE = os.path.join(BASE, 'PADRON_FINAL_21JUL2026.csv')
PARTICIPA = os.path.expanduser(
    '~/Downloads/CORTE DEL 22 DE JULIO AL 29 DE JULIO.xlsx')
CORTE = '2026-08-02'
SALIDA = os.path.join(BASE, 'PADRON_FINAL_02AGO2026')

# sexo: la PALABRA gana a la letra. Y la letra depende del esquema de la hoja:
# si aparece H es H/M (M=Mujer); si solo hay F, es F/M (M=Hombre). Verificado
# hoja por hoja en cortes anteriores; la lista fija de 02_NORMALIZA es incorrecta
# para algunas.
PALABRA = {'FEMENINO': 'Mujer', 'FEMENINA': 'Mujer', 'MUJER': 'Mujer',
           'MASCULINO': 'Hombre', 'MACULINO': 'Hombre', 'MASCULNO': 'Hombre',
           'HOMBRE': 'Hombre'}


def limpio(x):
    """str(NaN) es 'nan' y acaba escrito como 'NAN' en el padrón: 1,788 CURP
    basura la primera vez. Todo campo de texto pasa por aquí."""
    v = str(x or '').strip()
    return '' if v.lower() in ('nan', 'nat', 'none', 's/d', 'n/a', '-') else v


def curp_valida(x):
    v = limpio(x).upper()
    return v if re.fullmatch(r'[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d', v) else ''


def edad_valida(x):
    d = re.sub(r'\D', '', limpio(x))
    return d if d and 1 <= int(d) <= 102 else ''


def correo_valido(x):
    v = limpio(x).lower()
    return v if re.fullmatch(r'[^@\s]+@[^@\s]+\.[a-z]{2,}', v) else ''


def titulo(s):
    """El padrón guarda Title Case; las fuentes llegan en MAYÚSCULAS."""
    s = ' '.join(limpio(s).split())
    if not s:
        return ''
    chicas = {'DE', 'DEL', 'LA', 'LAS', 'LOS', 'Y'}
    out = []
    for i, w in enumerate(s.split()):
        out.append(w.lower() if (i and w.upper() in chicas) else w.capitalize())
    return ' '.join(out)


def sexo_de(valor, curp='', hoja_tiene_h=True):
    v = inc.sin_acentos(valor).upper().strip()
    if v in PALABRA:
        return PALABRA[v]
    c = str(curp or '').strip().upper()
    if len(c) >= 11 and c[10] in 'HM':          # CURP: posición 11, autoritativa
        return 'Hombre' if c[10] == 'H' else 'Mujer'
    if v in ('H',):
        return 'Hombre'
    if v in ('F',):
        return 'Mujer'
    if v == 'M':
        return 'Mujer' if hoja_tiene_h else 'Hombre'
    return ''


def _col(cols, *pats):
    for i, c in enumerate(cols):
        cn = inc.sin_acentos(c).upper().strip()
        for p in pats:
            if re.search(p, cn):
                return i
    return None


def de_bddconcentrado():
    """Registros con todos los campos, hoja por hoja."""
    out = []
    for hoja in pd.ExcelFile(inc.NUEVO).sheet_names:
        if hoja == 'Índice':
            continue
        crudo = pd.read_excel(inc.NUEVO, sheet_name=hoja, header=None)
        if crudo.empty:
            continue
        hi = inc._fila_encabezado(crudo)
        if hi is None:
            continue            # hojas sin encabezado: solo apellidos, sin campos
        cols = crudo.iloc[hi].tolist()
        ix = {k: _col(cols, *p) for k, p in {
            'nombre': (r'^NOMBRE',), 'apeP': (r'APELLIDOP', r'APELLIDO P', r'PATERNO'),
            'apeM': (r'APELLIDOM', r'APELLIDO M', r'MATERNO'),
            'sexo': (r'^SEXO', r'GENERO'), 'tel': (r'^TELEFONO', r'^TEL'),
            'curp': (r'^CURP',), 'edad': (r'^EDAD',), 'correo': (r'CORREO', r'MAIL'),
            'colonia': (r'^COLONIA',), 'terr': (r'TERRITORIAL',),
            'fecha': (r'^FECHA$', r'^FECHA '),
        }.items()}
        tiene_h = any(inc.sin_acentos(str(v)).upper().strip() == 'H'
                      for v in crudo.iloc[hi+1:, ix['sexo']].dropna()) \
            if ix['sexo'] is not None else True
        for _, f in crudo.iloc[hi + 1:].iterrows():
            v = f.tolist()
            g = lambda k: (v[ix[k]] if ix[k] is not None and ix[k] < len(v) else '')
            nom = inc.norm_nombre(g('nombre'), g('apeP'), g('apeM'))
            tel = inc.tel10(g('tel'))
            if not nom and not tel:
                continue
            out.append({
                'nombre': titulo(g('nombre')), 'apellidoP': titulo(g('apeP')),
                'apellidoM': titulo(g('apeM')),
                'sexo': sexo_de(g('sexo'), g('curp'), tiene_h),
                'edad': edad_valida(g('edad')),
                'telefono': tel, 'curp': curp_valida(g('curp')),
                'correo': correo_valido(g('correo')),
                'colonia': titulo(g('colonia')), 'territorial': titulo(g('terr')),
                'nom_norm': nom, 'origen': inc.dependencia(hoja),
            })
    return out


def de_participacion():
    d = pd.read_excel(PARTICIPA).fillna('')
    c = lambda pat: next((x for x in d.columns if re.search(pat, str(x), re.I)), None)
    cn, cp, cm = c(r'NOMBRE'), c(r'APELLIDO *P'), c(r'APE+LIDO *M')
    ct, cc, cg = c(r'TEL'), c(r'COLONIA'), c(r'GENERO|SEXO')
    tiene_h = any(str(x).strip().upper() == 'H' for x in d[cg]) if cg else True
    out = []
    for r in d.itertuples(index=False):
        g = lambda col: (getattr(r, str(col).replace(' ', '_').replace('.', '_'), '')
                         if col else '')
        row = dict(zip(d.columns, r))
        nom = inc.norm_nombre(row.get(cn), row.get(cp), row.get(cm))
        tel = inc.tel10(row.get(ct))
        if not nom and not tel:
            continue
        out.append({
            'nombre': titulo(row.get(cn)), 'apellidoP': titulo(row.get(cp)),
            'apellidoM': titulo(row.get(cm)),
            'sexo': sexo_de(row.get(cg), '', tiene_h), 'edad': '',
            'telefono': tel, 'curp': '', 'correo': '',
            'colonia': titulo(row.get(cc)), 'territorial': '',
            'nom_norm': nom, 'origen': 'Participación Ciudadana',
        })
    return out


def main():
    p = pd.read_csv(VIGENTE, dtype=str).fillna('')
    print(f'padrón vigente (CONGELADO): {len(p):,} personas')

    por_tel, por_nom = {}, {}
    for r in p.itertuples(index=False):
        t = inc.tel10(r.telefono)
        n = inc.norm_nombre(r.nombre, r.apellidoP, r.apellidoM)
        if t:
            por_tel.setdefault(t, r.idPersona)
        if n:
            por_nom.setdefault(n, r.idPersona)

    regs = de_bddconcentrado() + de_participacion()
    print(f'registros leídos de las fuentes: {len(regs):,}')

    # colapsar candidatas entre sí ANTES de compararlas con la base
    cand, tocadas = {}, 0
    for r in regs:
        if r['telefono'] and r['telefono'] in por_tel:
            tocadas += 1
            continue
        if not r['telefono'] and r['nom_norm'] in por_nom:
            tocadas += 1
            continue
        k = ('T', r['telefono']) if r['telefono'] else ('N', r['nom_norm'])
        if k in cand:
            for campo in ('curp', 'correo', 'edad', 'colonia', 'territorial', 'sexo'):
                if not cand[k][campo] and r[campo]:
                    cand[k][campo] = r[campo]
            cand[k]['origenes'].add(r['origen'])
            cand[k]['nRegistros'] += 1
        else:
            r = dict(r, origenes={r['origen']}, nRegistros=1)
            cand[k] = r
    # una persona sin teléfono cuyo nombre ya salió con teléfono no es nueva
    con_tel = {v['nom_norm']: k for k, v in cand.items() if k[0] == 'T' and v['nom_norm']}
    for k in [k for k in cand if k[0] == 'N' and cand[k]['nom_norm'] in con_tel]:
        d = cand[con_tel[cand[k]['nom_norm']]]
        d['origenes'] |= cand[k]['origenes']
        d['nRegistros'] += cand[k]['nRegistros']
        del cand[k]

    print(f'  ya estaban en el padrón:   {tocadas:,}')
    print(f'  ALTAS (personas nuevas):   {len(cand):,}')

    # ¿cuáles son nuevas de esta semana y cuáles venían de cortes previos sin
    # integrar? El deck lo presenta separado: no es lo mismo captar que recuperar.
    firmas_prev = {inc.firma(r) for r in inc.extrae_libro(inc.PREVIO)}
    for h in pd.ExcelFile(inc.SU_PREVIO).sheet_names:
        firmas_prev |= {inc.firma(r) for r in inc.extrae_hoja(inc.SU_PREVIO, h)}
    pares_prev = {(x[0], x[1]) for x in firmas_prev}
    for r in cand.values():
        r['recuperada'] = ((r['nom_norm'], r['telefono']) in pares_prev
                           and 'Participación Ciudadana' not in r['origenes'])

    ini = int(p['idPersona'].astype(int).max()) + 1
    filas = []
    for i, (k, r) in enumerate(sorted(cand.items(), key=lambda kv: kv[1]['nom_norm'])):
        ident = ('telefono+nombre' if r['telefono'] and r['nom_norm']
                 else 'telefono' if r['telefono'] else 'nombre')
        filas.append({
            'idPersona': ini + i, 'nombre': r['nombre'], 'apellidoP': r['apellidoP'],
            'apellidoM': r['apellidoM'], 'sexo': r['sexo'], 'edad': r['edad'],
            'telefono': r['telefono'], 'curp': r['curp'], 'correo': r['correo'],
            'colonia': r['colonia'], 'territorial': r['territorial'],
            'clasificacion': ('Identificable (tel + nombre)' if r['telefono'] and r['nom_norm']
                              else 'Identificable (nombre)'),
            'identificacion': ident, 'procedencia': 'Delta CUH3Jun',
            'fuentes': f'Delta 02Ago26', 'origenes': ' | '.join(sorted(r['origenes'])),
            'nRegistros': r['nRegistros'],
        })
    nuevas = pd.DataFrame(filas)
    out = pd.concat([p, nuevas], ignore_index=True)

    import json
    recs = [r for r in cand.values() if r['recuperada']]
    nuev = [r for r in cand.values() if not r['recuperada']
            and 'Participación Ciudadana' not in r['origenes']]
    part = [r for r in cand.values() if 'Participación Ciudadana' in r['origenes']]
    desglose = {
        'corte': CORTE, 'total': len(out), 'base_previa': len(p),
        'altas': len(cand),
        'nuevas': len(nuev), 'recuperadas': len(recs), 'participacion': len(part),
        'rec_con_tel': sum(1 for r in recs if r['telefono']),
        'rec_con_colonia': sum(1 for r in recs if r['colonia']),
        'por_dependencia': dict(collections.Counter(
            x for r in cand.values() for x in r['origenes']).most_common()),
        'rec_por_dependencia': dict(collections.Counter(
            x for r in recs for x in r['origenes']).most_common()),
        'con_telefono': int((out['telefono'].fillna('') != '').sum()),
        'con_colonia': int((out['colonia'].fillna('') != '').sum()),
        'con_sexo': int((out['sexo'].fillna('') != '').sum()),
        'mujeres': int((out['sexo'] == 'Mujer').sum()),
        'hombres': int((out['sexo'] == 'Hombre').sum()),
        'nRegistros': int(pd.to_numeric(out['nRegistros'], errors='coerce').fillna(1).sum()),
    }
    json.dump(desglose, open(os.path.join(BASE, 'aporte_02ago.json'), 'w'),
              indent=1, ensure_ascii=False)
    print(f'\n  desglose -> aporte_02ago.json')

    out.to_csv(SALIDA + '.csv', index=False)
    out.to_excel(SALIDA + '.xlsx', index=False, sheet_name='Padron')

    # SQL de inserción SOLO de las altas: la base ya está en Neon y reinsertarla
    # duplicaría 98,739 filas
    def sq(v):
        v = '' if v is None else str(v)
        return 'NULL' if v == '' else "'" + v.replace("'", "''") + "'"

    cols = [c for c in out.columns if c != 'idPersona']
    with open(SALIDA + '.sql', 'w', encoding='utf-8') as f:
        f.write('-- Altas al padrón, corte 02-ago-2026. La base previa NO se\n'
                '-- reinserta: ya está en Neon.\n')
        f.write('BEGIN;\n')
        for r in nuevas.itertuples(index=False):
            d = dict(r._asdict())
            f.write('INSERT INTO "Padron" ("idPersona",' +
                    ','.join(f'"{c}"' for c in cols) + ') VALUES (' +
                    str(d['idPersona']) + ',' +
                    ','.join(sq(d[c]) for c in cols) + ');\n')
        f.write('COMMIT;\n')
    print(f'\nPADRÓN 02-AGO: {len(out):,} personas   ({len(p):,} + {len(nuevas):,})')
    print(f'  por dependencia:')
    for k, v in collections.Counter(
            x for r in cand.values() for x in r['origenes']).most_common():
        print(f'    {k:26} {v:5,}')

    # ── auditoría ──
    print('\nAUDITORÍA')
    ids = out['idPersona'].astype(int)
    print(f'  ids contiguos 1..{len(out):,}: {list(ids) == list(range(1, len(out)+1))}')
    tel = out['telefono'].fillna('')
    mal = tel[(tel != '') & (~tel.str.fullmatch(r'\d{10}'))]
    print(f'  teléfonos no de 10 dígitos: {len(mal)}')
    dup = out[(tel != '')].duplicated(subset=['telefono', 'nombre', 'apellidoP'])
    print(f'  duplicados tel+nombre+apellido: {dup.sum()}')
    ed = pd.to_numeric(out['edad'], errors='coerce').dropna()
    print(f'  edades fuera de 1-102: {((ed < 1) | (ed > 102)).sum()}')
    cu = out['curp'].fillna('')
    print(f'  CURP presentes: {(cu.str.len() == 18).sum():,}  · malformados: '
          f'{((cu != "") & (cu.str.len() != 18)).sum()}')
    print(f'  sin sexo: {(out["sexo"].fillna("") == "").sum():,}')
    print(f'\n  -> {SALIDA}.csv')


if __name__ == '__main__':
    main()

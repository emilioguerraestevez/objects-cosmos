#!/usr/bin/env python3
"""El árbol de servicios por dependencia — el que va a regir el sistema.

Se arma de tres fuentes que se corrigen entre sí:

  · el Manual Administrativo dice QUIÉN puede prestar cada servicio
  · el SUAC dice qué se pide por ventanilla y cuánto
  · las listas semanales dicen qué atiende cada dirección por su cuenta

Las listas traen el servicio en una columna que se llama distinto en cada hoja
—«Tipo de Servicio», «Asunto», «Gestión», «Tipo de asesoría»— y a un nivel más
fino que el catálogo: ZUMBA, CORTE, PSICOLOGÍA. Eso son ACTIVIDADES, no
servicios; el nombre de la pestaña, cuando es Lagunilla o Felipe Pescador, es
una SEDE. Antes se tomaba la pestaña como servicio y por eso Género aparecía
prestando un servicio llamado «Felipe Pescador».

    dependencia → servicio (catálogo) → actividad (lo que trae la hoja)

`MAPEO_ACTIVIDADES.csv` es la tabla de decisión: patrón → servicio. Se edita a
mano y manda sobre cualquier heurística.

    python3 arbol_servicios.py
"""
import collections
import csv
import os
import re
import unicodedata

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, 'catalogo')
MAPEO = os.path.join(OUT, 'MAPEO_ACTIVIDADES.csv')
CATALOGO = os.path.join(OUT, 'CATALOGO_SERVICIOS.csv')


def sa(s):
    s = unicodedata.normalize('NFD', str(s or ''))
    return ''.join(c for c in s if unicodedata.category(c) != 'Mn').upper()


def reglas():
    out = []
    for r in csv.DictReader(open(MAPEO, encoding='utf-8')):
        # el patrón se normaliza igual que el dato: sa() descompone la Ñ y le
        # quita la tilde, así que «UÑAS» en la regla nunca pegaría contra «UNAS»
        out.append((r['dependencia'], re.compile(sa(r['patron']), re.I),
                    r['servicio'], r['nivel'], r['nota']))
    return out


REGLAS = reglas()
# cuando la fila no declara actividad, el servicio lo da la pestaña
PESTANAS = {(r['dependencia'], r['pestana']): r['servicio']
            for r in csv.DictReader(open(os.path.join(OUT, 'MAPEO_PESTANAS.csv'),
                                         encoding='utf-8'))}


def por_pestana(dep, pestana):
    if (dep, pestana) in PESTANAS:
        return PESTANAS[(dep, pestana)]
    for (d, p), serv in PESTANAS.items():          # las hojas traen el nombre cortado
        if d == dep and p != '*' and (sa(p).startswith(sa(pestana)[:18]) or
                                      sa(pestana).startswith(sa(p)[:18])):
            return serv
    return PESTANAS.get((dep, '*'))                # comodín por dependencia


def clasifica(dep, actividad):
    """actividad cruda -> (servicio del catálogo, nivel). Primera regla que pega."""
    t = sa(actividad)
    for d, pat, serv, nivel, _ in REGLAS:
        if d == dep and pat.search(t):
            return serv, nivel
    return None, None


def actividades_del_libro():
    """El inventario crudo: hoja, columna, valor, cuántas veces."""
    import pandas as pd
    ruta = os.path.expanduser('~/Downloads/drive-download-20260817T051938Z-1-001/'
                              'BDDConcentrado_General_Unificado_13ago.xlsx')
    # «Tipo de violencia» NO entra: describe el caso, no el servicio. En
    # Reacción Violeta convive con «Tipo de asesoría», que sí dice qué se dio
    # (psicológico o jurídico); contar las dos columnas duplicaría cada atención.
    COLS = ('TIPO DE SERVICIO', 'ASUNTO', 'GESTIÓN', 'GESTION', 'TIPO DE ASESORÍA',
            'TIPO DE ASESORIA', 'SERVICIO', 'MOTIVO', 'OBSERVACIONES',
            'APOYO', 'PROGRAMA', 'ACTIVIDAD')
    DEPS = {'CULT': 'Cultura', 'DS': 'Desarrollo Social', 'EG': 'Genero',
            'GOB': 'Gobierno', 'JUR': 'Jurídico', 'OBRAS': 'Obras',
            'SEG': 'Seguridad', 'SU': 'Servicios Urbanos',
            'PC-PCyVS': 'Protección Civil', 'PC-GIRPC': 'Protección Civil'}
    x = pd.ExcelFile(ruta)
    filas = []
    for hoja in x.sheet_names:
        if hoja == 'Índice':
            continue
        d = pd.read_excel(ruta, sheet_name=hoja, header=None)
        if d.empty:
            continue
        hi = next((i for i in range(min(10, len(d)))
                   if any(str(c).strip().upper().startswith('NOMBRE') for c in d.iloc[i])), None)
        if hi is None:
            continue
        cols = [str(c).strip().upper() for c in d.iloc[hi]]
        dep = DEPS.get(hoja.split('_')[0], hoja.split('_')[0])
        sede = hoja.split('_', 1)[1] if '_' in hoja else hoja
        for j, c in enumerate(cols):
            if c not in COLS:
                continue
            cuenta = collections.Counter(' '.join(str(z).split())
                                         for z in d.iloc[hi + 1:, j]
                                         if str(z).strip() not in ('nan', ''))
            for val, n in cuenta.items():
                filas.append((dep, sede, c, val, n))
    return filas


def main():
    crudo = actividades_del_libro()
    arbol = collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
    sedes = collections.defaultdict(set)
    sin_regla = collections.Counter()
    for dep, sede, col, val, n in crudo:
        serv, nivel = clasifica(dep, val)
        if serv is None:
            sin_regla[(dep, val)] += n
            continue
        arbol[dep][serv][val] += n
        if sede and not sede.lower().startswith(('hoja', 'datos', 'sub', 'concentrado')):
            sedes[(dep, serv)].add(sede)

    # el SUAC entra al mismo árbol, con su propio servicio ya catalogado
    for r in csv.DictReader(open(CATALOGO, encoding='utf-8')):
        if r['canal'].startswith('SUAC') and int(r['folios_corte'] or 0):
            arbol[r['clave_padron']][r['servicio']]['— por ventanilla del SUAC —'] += \
                int(r['folios_corte'])

    with open(os.path.join(OUT, 'ARBOL_SERVICIOS.csv'), 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['dependencia', 'servicio', 'registros', 'actividades',
                    'sedes', 'canal'])
        for dep in sorted(arbol):
            for serv, act in sorted(arbol[dep].items(), key=lambda kv: -sum(kv[1].values())):
                suac = '— por ventanilla del SUAC —' in act
                w.writerow([dep, serv, sum(act.values()),
                            ' · '.join(f'{a} ({n})' for a, n in act.most_common(12)
                                       if not a.startswith('—')),
                            ' · '.join(sorted(sedes[(dep, serv)])),
                            'SUAC' if suac else 'lista semanal'])

    print('ÁRBOL DE SERVICIOS POR DEPENDENCIA\n')
    for dep in sorted(arbol, key=lambda d: -sum(sum(a.values()) for a in arbol[d].values())):
        tot = sum(sum(a.values()) for a in arbol[dep].values())
        print(f'{dep}  ·  {len(arbol[dep])} servicios · {tot:,} registros')
        for serv, act in sorted(arbol[dep].items(), key=lambda kv: -sum(kv[1].values())):
            n = sum(act.values())
            top = ', '.join(a.lower() for a, _ in act.most_common(4) if not a.startswith('—'))
            sed = sedes[(dep, serv)]
            print(f'   ├─ {n:6,}  {serv[:56]}')
            if top:
                print(f'   │        {top[:96]}')
            if sed:
                print(f'   │        sedes: {" · ".join(sorted(sed))[:88]}')
        print()
    if sin_regla:
        print(f'SIN REGLA: {len(sin_regla)} valores, {sum(sin_regla.values()):,} registros')
        for (dep, val), n in sin_regla.most_common(10):
            print(f'   {n:5,}  [{dep}] {val[:60]}')


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Base única de atenciones — corte 15-oct-2026.

Copia de base_unica_25sep.py adaptada a las fuentes del 15-oct. Reconstrucción
COMPLETA desde las tres fuentes crudas (no incremental).

CAMBIOS DE ESTE CORTE (verificados contra el archivo, no supuestos):
  · Concentrado de dependencias: 83 pestañas, igual que en 25-sep. Mismos
    prefijos (CE, DS, EG, GOB, JUR, OBRAS, PC1, PC2, SC, SU) — todos ya en
    DEPS, ninguno nuevo.
  · DS_D (511 filas) y DS_Hoja1 (1,008 filas) siguen siendo las mismas hojas
    basura de siempre, con EXACTAMENTE el mismo número de filas que en 25-sep
    y 11-sep — relleno estático confirmado otra vez.
  · DS_Hoja 1 (con espacio, 31,015 filas) sigue con encabezado real en la
    fila 2 (N°/EVENTO/FECHA/NOMBRE/PATERNO/MATERNO/CURP/SEXO/...) — mismo
    tratamiento que 30-sep, sin POSICIONAL.
  · SC_SUB sigue con columnas "Apellido P"/"Apellido M" (CON ESPACIO) — se
    mantiene el ALIAS agregado en 30-sep.
  · JUR_ASESORÍAS sigue con filas-divisor de mes intercaladas, un solo
    encabezado real en la fila 2 — igual que siempre, parser genérico.
  · EG trae 8 pestañas por programa (Reaccion Violeta, Lactario, Casa de la
    Mujer, Lagunilla, Felipe Pescador, PROTOCOLO VIOLETA, Centro de
    Capacitación "Las...", Beneficiarias Programa CVA, Capacitaciónes) en vez
    de un solo concentrado — cada una con encabezado real propio, el parser
    genérico las lee bien.
  · SUAC (261014): mismas 19 columnas, misma hoja "BASE 24-25", 68,401 filas
    (antes 68,401... verificar en auditoría). Sin cambios de esquema.
  · Amazónica: AmazónicaIA_reportes-ciudadanos-2026-10-12.xlsx, mismo formato
    de hoja "BlankSpace" (12 columnas), 830 filas (antes 774 el 21-sep).
  · NOTA (16-oct-2026): el usuario confirmó que "Amazónica" es un CANAL, no
    una dependencia — de_amazonica() sigue etiquetando Dependencia='Amazónica'
    tal como siempre (no se tocó el contrato del LAYOUT ni el módulo
    compartido), pero el test de compatibilidad contra el Directorio
    (DEPENDENCIAS_SERVICIOS_CORREGIDO.csv, 232 servicios/11 DG) reclasifica
    esas filas por el contenido real del servicio antes de comparar — igual
    que se hizo para construir el Directorio mismo.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import base_unica as bu

BASE = bu.BASE
OUT = bu.OUT
DES = os.path.expanduser('~/Downloads')

bu.LIBRO = os.path.join(DES, 'BDDConcentrado_General_Unificado_15oct.xlsx')
bu.SUAC = os.path.join(DES, 'CESAC - BASE SUAC (261014).xlsx')
bu.AMZ = os.path.join(DES, 'AmazónicaIA_reportes-ciudadanos-2026-10-12.xlsx')
bu.CORTE = '2026-10-15'

bu.DEPS = {
    'CULT': 'Cultura', 'CyE': 'Cultura', 'EC': 'Cultura', 'CONC': 'Cultura', 'CE': 'Cultura',
    'DS': 'Desarrollo Social', 'DGDS': 'Desarrollo Social',
    'EG': 'Genero', 'DEEGeIS': 'Genero',
    'GOB': 'Gobierno',
    'JUR': 'Jurídico', 'SL': 'Jurídico', 'AyM': 'Jurídico',
    'OBRAS': 'Obras', 'OU': 'Obras', 'DGODU': 'Obras',
    'SEG': 'Seguridad', 'SC': 'Seguridad',
    'SU': 'Servicios Urbanos', 'DGSU': 'Servicios Urbanos',
    'PC-PCyVS': 'Protección Civil', 'PC-GIRPC': 'Protección Civil',
    'PC1': 'Protección Civil', 'PC2': 'Protección Civil',
}

# "Apellido P"/"Apellido M" (con espacio) de SC_SUB — igual que 30-sep.
bu.ALIAS['apellido_paterno'] = bu.ALIAS['apellido_paterno'] + ('APELLIDO P',)
bu.ALIAS['ApellidoM'] = bu.ALIAS['ApellidoM'] + ('APELLIDO M',)

bu.BASURA = {'DS_D', 'DS_Hoja1', 'JUR_Hoja1'}
bu.POSICIONAL = {}  # ninguna hoja sin encabezado real este corte

SALTAR_LIBRO = ('Índice', 'PC1_ACUMULADO', 'PC2_ACUMULADO')

DEP_CONOCIDA = {'Servicios Urbanos', 'Gobierno', 'Seguridad', 'Cultura',
                'Protección Civil', 'Obras', 'Desarrollo Social', 'Jurídico',
                'Administración', 'Participación Ciudadana'}
AREA_MALA_KEYWORDS = [
    (('ALUMBRADO', 'BACHEO', 'COLADERA', 'REGISTRO', 'AGUA POTABLE', 'AREAS VERDES',
      'ÁREAS VERDES', 'BANQUETA', 'MOBILIARIO URBANO', 'BARRIDO', 'CHATARRIZACION',
      'CHATARRIZACIÓN', 'BASURA', 'TRIQUES', 'OBSTACULOS', 'OBSTÁCULOS', 'REENCARPETADO',
      'NOMENCLATURA', 'TOPE O REDUCTOR'), 'Servicios Urbanos'),
    (('FORESTAL', 'ADOPCIÓN DE ÁREAS', 'ADOPCION DE AREAS'), 'Servicios Urbanos'),
    (('VERIFICACIÓN ADMINISTRATIVA EN MATERIA DE CONSTRUCCIONES', 'BALIZAMIENTO',
      'OPINION TECNICA', 'OPINIÓN TÉCNICA', 'ESTUDIO TÉCNICO', 'ESTUDIO TECNICO'), 'Obras'),
    (('FOROS Y ESPACIOS CULTURALES',), 'Cultura'),
    (('RONDINES DE VIGILANCIA',), 'Seguridad'),
    (('COMERCIO EN VÍA PÚBLICA', 'COMERCIO EN VIA PUBLICA', 'VERIFICACIÓN ADMINISTRATIVA',
      'VERIFICACION ADMINISTRATIVA', 'CONFLICTOS VECINALES', 'POBLACIÓN EN SITUACIÓN DE CALLE',
      'POBLACION EN SITUACION DE CALLE'), 'Gobierno'),
]


def corrige_area_mala(filas):
    n = 0
    for r in filas:
        if r['Dependencia'] in DEP_CONOCIDA or r['Territorial']:
            continue
        txt = bu.sa(r['Dependencia']).upper()
        nueva = None
        for kws, dep in AREA_MALA_KEYWORDS:
            if any(bu.sa(k).upper() in txt for k in kws):
                nueva = dep
                break
        r['Dependencia'] = nueva or 'Servicios Urbanos'
        n += 1
    return n


def bu_sheets(ruta, saltar):
    import pandas as pd
    return [s for s in pd.ExcelFile(ruta).sheet_names if s not in saltar and s not in bu.BASURA]


def main():
    bu.DIC = bu.dic_nombres()
    print(f'diccionario de nombres del padrón: {len(bu.DIC):,} nombres')
    print('leyendo el concentrado de las dependencias (15-oct)…')
    libro, notas = bu.del_libro(bu.LIBRO, saltar=SALTAR_LIBRO)
    print(f'  {len(libro):,} registros')
    notas.append(('PC1_ACUMULADO', 'saltada a propósito: no se pudo verificar que no duplique las hojas semanales'))
    notas.append(('PC2_ACUMULADO', 'saltada a propósito, mismo motivo'))

    print('leyendo el SUAC (261014)…')
    suac = bu.del_suac(bu.SUAC)
    n_area_mala = corrige_area_mala(suac)
    print(f'  {len(suac):,} registros ({n_area_mala} con ÁREA ADMINISTRATIVA mal capturada, reclasificados por palabra clave)')
    if n_area_mala:
        notas.append(('SUAC (261014)', f'{n_area_mala}/{len(suac)} filas con ÁREA ADMINISTRATIVA mal capturada (nombre de servicio en vez de área) — reclasificadas por palabra clave, mismo patrón que cortes anteriores'))

    print('leyendo Amazónica (12-oct)…')
    amz = bu.de_amazonica(bu.AMZ)
    print(f'  {len(amz):,} registros')

    filas = libro + suac + amz
    dic = bu.DIC
    n_dic = 0
    for r in filas:
        if not r.get('Sexo'):
            r['Sexo'] = bu.sexo_norm(r.get('_sexo', ''), r['CURP'])
        if not r['Sexo'] and dic:
            pn = bu.sa(r['nombre']).upper().split()
            if pn and pn[0] in dic:
                r['Sexo'] = dic[pn[0]]
                n_dic += 1
    print(f'  sexo inferido por nombre: {n_dic:,}')

    os.makedirs(OUT, exist_ok=True)
    ruta = os.path.join(OUT, f'BASE_UNICA_{bu.CORTE}.csv')
    import csv
    with open(ruta, 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=bu.LAYOUT)
        w.writeheader()
        for r in filas:
            w.writerow({c: r.get(c, '') for c in bu.LAYOUT})

    import openpyxl
    from openpyxl.styles import Font
    from openpyxl.utils import get_column_letter
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Base única'
    ws.append(bu.LAYOUT)
    for c in ws[1]:
        c.font = Font(bold=True)
    for r in filas:
        ws.append([r.get(c, '') for c in bu.LAYOUT])
    ws.freeze_panes = 'A2'
    for k, c in enumerate(bu.LAYOUT, 1):
        ws.column_dimensions[get_column_letter(k)].width = {
            'nombre': 22, 'apellido_paterno': 18, 'ApellidoM': 18, 'colonia': 24,
            'calle': 26, 'observaciones': 44, 'servicio': 34, 'Folio': 22,
            'Dependencia': 20, 'Territorial': 22}.get(c, 12)
    wb.save(os.path.join(OUT, f'BASE_UNICA_{bu.CORTE}.xlsx'))

    import collections
    fol = collections.Counter(r['Folio'] for r in filas)
    sint = [r for r in filas if r['Folio'].startswith('CUH/')]
    fech = [r['fecha'] for r in filas if r['fecha']]
    with open(os.path.join(OUT, f'AUDITORIA_{bu.CORTE}.md'), 'w', encoding='utf-8') as fh:
        fh.write(f'# Base única · corte {bu.CORTE}\n\n'
                 f'**{len(filas):,} registros · {len(bu.LAYOUT)} columnas.** '
                 f'Reconstrucción completa desde las tres fuentes (no incremental).\n\n'
                 f'| fuente | registros |\n|---|---:|\n'
                 f'| concentrado de dependencias ({len(bu_sheets(bu.LIBRO, SALTAR_LIBRO))} pestañas usadas) | {len(libro):,} |\n'
                 f'| SUAC | {len(suac):,} |\n| Amazónica (corte 12-oct) | {len(amz):,} |\n\n'
                 f'## Llave\n\n'
                 f'- folios distintos: **{len(fol):,}**\n'
                 f'- folios que se repiten: **{sum(1 for n in fol.values() if n > 1):,}**\n'
                 f'- folios sintetizados: **{len(sint):,}** ({100*len(sint)/len(filas):.0f}%)\n\n'
                 f'## Cobertura\n\n| columna | con dato | % |\n|---|---:|---:|\n')
        for c in bu.LAYOUT:
            n = sum(1 for r in filas if r.get(c))
            fh.write(f'| {c} | {n:,} | {100*n/len(filas):.1f}% |\n')
        fh.write(f'\n## Rangos\n\n- fecha de atención: {min(fech)} → {max(fech)} '
                 f'({len(fech):,} con dato)\n')
        if notas:
            fh.write('\n## Hojas no cargadas / saltadas / huecos / correcciones\n\n')
            for h, por in notas:
                fh.write(f'- **{h}** — {por}\n')
        fh.write('\n## Por dependencia\n\n| dependencia | registros |\n|---|---:|\n')
        for d, n in collections.Counter(r['Dependencia'] for r in filas).most_common():
            fh.write(f'| {d} | {n:,} |\n')

    print(f'\n{len(filas):,} registros · {len(bu.LAYOUT)} columnas → {ruta}')
    dep = collections.Counter(r['Dependencia'] for r in filas)
    print('\npor dependencia:')
    for d, n in dep.most_common():
        print(f'   {n:7,}  {d}')
    if notas:
        print('\nhojas no cargadas/saltadas/huecos/correcciones:')
        for h, por in notas:
            print(f'   · {h}: {por}')
    return filas


if __name__ == '__main__':
    main()

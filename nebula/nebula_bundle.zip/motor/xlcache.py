"""Lee hojas de Excel abriendo el libro UNA sola vez (antes se reabría el archivo por cada hoja)."""
import pandas as pd
_C = {}


def libro(ruta):
    x = _C.get(ruta)
    if x is None:
        x = _C[ruta] = pd.ExcelFile(ruta)
    return x


def hojas(ruta):
    return libro(ruta).sheet_names


def hoja(ruta, nombre, header=None):
    return libro(ruta).parse(nombre, header=header)


def limpia():
    _C.clear()

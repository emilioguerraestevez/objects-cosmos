"""Lee hojas de Excel o CSV abriendo el libro UNA sola vez (antes se reabría el archivo por cada hoja)."""
import os
import pandas as pd
_C = {}


def _csv(ruta):
    return str(ruta).lower().endswith('.csv')


def libro(ruta):
    x = _C.get(ruta)
    if x is None:
        x = _C[ruta] = pd.ExcelFile(ruta)
    return x


def hojas(ruta):
    if _csv(ruta):
        return [os.path.splitext(os.path.basename(ruta))[0]]
    return libro(ruta).sheet_names


def hoja(ruta, nombre, header=None):
    if _csv(ruta):
        return pd.read_csv(ruta, header=header, dtype=object, encoding='utf-8-sig', encoding_errors='replace', on_bad_lines='skip')
    return libro(ruta).parse(nombre, header=header)


def limpia():
    _C.clear()

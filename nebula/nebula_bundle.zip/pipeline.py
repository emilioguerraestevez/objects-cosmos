# -*- coding: utf-8 -*-
"""Nebula · motor del corte semanal.

Recibe el concentrado de dependencias, el SUAC y Amazónica (más el padrón y la base anteriores) y entrega
UNA carpeta lista para IT: dos .sql, instructivo de carga, auditoría, avisos para Ana y huellas.

Todo corre en esta computadora. No envía nada a ningún servidor.
"""
import collections
import csv
import hashlib
import json
import os
import shutil
import sys
import time
import zipfile

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(AQUI, 'motor'))
import pandas as pd                       # noqa: E402
import base_unica as bu                   # noqa: E402
import base_unica_15oct as b15            # noqa: E402
import normaliza_directorio as nd         # noqa: E402
import incremento_13ago as inc            # noqa: E402
import consolida_02ago as c02             # noqa: E402

CONFIG = json.load(open(os.path.join(AQUI, 'config.json'), encoding='utf-8'))
SALTAR_BASE = ('Índice', 'PC1_ACUMULADO', 'PC2_ACUMULADO')
COLS_BASE = bu.LAYOUT + ['Canal', 'Naturaleza', 'dependencia_origen', 'servicio_origen']
COLS_PADRON = ['idPersona', 'nombre', 'apellidoP', 'apellidoM', 'sexo', 'edad', 'telefono', 'curp', 'correo',
               'colonia', 'territorial', 'clasificacion', 'identificacion', 'procedencia', 'fuentes', 'origenes', 'nRegistros']
MESES = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC']


def _sha(ruta):
    h = hashlib.sha256()
    with open(ruta, 'rb') as fh:
        for b in iter(lambda: fh.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def _etiqueta(corte):
    a, m, d = corte.split('-')
    return f'{d}{MESES[int(m) - 1]}{a}'


def _q(v):
    if v is None or v == '' or (isinstance(v, float) and pd.isna(v)):
        return 'NULL'
    return "'" + str(v).replace("'", "''") + "'"


def _qi(v):
    s = str(v).strip()
    return s if s and s.lstrip('-').isdigit() else 'NULL'


# ───────────────────────────────────────────────────────────── base única
def base_unica(concentrado, suac, amazonica, corte, base_previa, avisos, log, sueltos=()):
    bu.SUAC, bu.AMZ, bu.CORTE = suac, amazonica, corte
    bu.DEPS['PCIU'] = bu.DEPS['PART'] = 'Participación Ciudadana'
    bu.DEPS['PC1'] = bu.DEPS['PC2'] = 'Protección Civil'
    bu.DIC = bu.dic_nombres()
    excluir = tuple(CONFIG['excluir_hojas'])
    notas = []

    libro, notas = [], []
    pref_sueltos = {pf for _, pf, _ in sueltos}
    if concentrado:
        log('Leyendo el concentrado de dependencias…')
        nombres = bu.xl.hojas(concentrado)
        ya = tuple(h for h in nombres if h.split('_')[0] in pref_sueltos)
        if ya:
            avisos['ana'].append('Subiste bases sueltas de ' + ', '.join(sorted(pref_sueltos)) + ' y también un concentrado que ya las traía: se usaron las sueltas.')
        l, n1 = bu.del_libro(concentrado, saltar=SALTAR_BASE + excluir + ya)
        libro += l; notas += n1
        log(f'  {len(l):,} registros del concentrado')
    for ruta, pf, nom in sueltos:
        log(f'Leyendo la base de {pf}: {nom}…')
        l, n1 = bu.del_libro(ruta, saltar=SALTAR_BASE + excluir, prefijo=pf)
        notas += n1
        if not l:
            avisos['ana'].append(f'El archivo «{nom}» no dio ningún registro: revisa que tenga encabezados (nombre, teléfono, fecha…).')
        libro += l
        log(f'  {len(l):,} registros')
    if not libro:
        avisos['ana'].append('No hay ninguna base de áreas (ni concentrado ni bases sueltas): el paquete solo trae SUAC y Amazónica.')
    log(f'  total de áreas: {len(libro):,} registros')
    for r in libro:
        r['_sexo_libro'] = r.get('Sexo', '')
    for h in excluir:
        avisos['emilio'].append(f'La hoja «{h}» viene en el concentrado pero está excluida por configuración (hoja nueva sin definir). No se integró.')

    # dependencias que ya no vienen -> se conservan del corte anterior (si lo hay)
    previo = []
    presentes = {r['Dependencia'] for r in libro}
    if base_previa and os.path.exists(base_previa):
        pb = pd.read_csv(base_previa, dtype=str).fillna('')
        pb = pb[pb['Canal'].str.startswith('Concentrado')]
        faltan = sorted(set(pb['dependencia_origen']) - presentes)
        for dep in faltan:
            sub = pb[pb['dependencia_origen'] == dep]
            for r in sub.to_dict('records'):
                r['Dependencia'], r['servicio'] = r['dependencia_origen'], r['servicio_origen']
                for k in ('lat', 'lng'):
                    r[k] = r[k] if r[k] != '' else ''
                r['_canal'] = 'Concentrado (conservado del corte anterior)'
                previo.append(r)
            avisos['ana'].append(f'Falta la base de «{dep}»: no venía en el concentrado. Se conservaron {len(sub):,} registros del corte anterior. '
                                 f'Pídela al área y vuelve a subir.')
            log(f'  Falta «{dep}»: se conservan {len(sub):,} registros del corte anterior')
    if not (base_previa and os.path.exists(base_previa)):
        avisos['emilio'].append('No se subió la base única del corte anterior: Nebula no puede saber qué áreas dejaron de venir (por ejemplo Cultura) ni conservar sus registros. Sube esa base (.csv) para compararla.')
    suac_f, amz = [], []
    if suac:
        log('Leyendo el SUAC…')
        suac_f = bu.del_suac(suac)
        b15.corrige_area_mala(suac_f)
        log(f'  {len(suac_f):,} registros')
    else:
        avisos['ana'].append('No subiste el SUAC (CESAC): este paquete no lo incluye.')
    if amazonica:
        log('Leyendo Amazónica…')
        amz = bu.de_amazonica(amazonica)
        log(f'  {len(amz):,} registros')
    else:
        avisos['ana'].append('No subiste Amazónica: este paquete no la incluye.')

    filas = libro + previo + suac_f + amz
    n_dic = 0
    for r in filas:
        if not r.get('Sexo'):
            r['Sexo'] = bu.sexo_norm(r.get('_sexo', ''), r.get('CURP', ''))
        if not r['Sexo'] and bu.DIC:
            pn = bu.sa(r['nombre']).upper().split()
            if pn and pn[0] in bu.DIC:
                r['Sexo'] = bu.DIC[pn[0]]; n_dic += 1
    for r in libro: r['_canal'] = 'Concentrado'
    for r in suac_f: r['_canal'] = 'SUAC'
    for r in amz: r['_canal'] = 'Amazónica'

    log('Normalizando al Directorio…')
    stat, sin, reglas, malos = nd.normaliza(filas)
    pendientes = [r for r in filas if not r.get('Naturaleza')]
    if pendientes:
        por = collections.Counter((r['dependencia_origen'], r['servicio_origen']) for r in pendientes)
        for (d, s), n in por.most_common():
            avisos['emilio'].append(f'{n} registro(s) con un servicio que el Directorio no tiene: «{s}» ({d}). Quedaron FUERA del paquete hasta que se decida a dónde van.')
        filas = [r for r in filas if r.get('Naturaleza')]
        log(f'  {len(pendientes)} registros con servicio sin equivalente: fuera del paquete, para decisión')

    # fuentes estancadas
    hoy = corte
    ult = collections.defaultdict(str)
    for r in filas:
        f = r.get('fecha') or ''
        k = r['_canal'] if r['_canal'] != 'Concentrado' else 'Concentrado · ' + r['dependencia_origen']
        if f and f > ult[k] and f <= hoy:
            ult[k] = f
    lim = time.strftime('%Y-%m-%d', time.localtime(time.mktime(time.strptime(corte, '%Y-%m-%d')) - CONFIG['dias_estancada'] * 86400))
    for k, f in sorted(ult.items()):
        if f < lim and 'conservado' not in k:
            avisos['ana'].append(f'«{k}» no trae registros desde el {f} (más de {CONFIG["dias_estancada"]} días). Pregunta si hubo actividad o si falta una actualización.')
    return filas, previo, libro, {'stat': stat, 'reglas': reglas, 'notas': notas, 'n_dic': n_dic, 'ult': dict(ult)}


# ─────────────────────────────────────────────────────────────── padrón
def padron(libro, padron_previo, corte, log):
    p = pd.read_csv(padron_previo, dtype=str).fillna('')
    log(f'Padrón anterior: {len(p):,} personas')
    por_tel, por_nom = {}, {}
    for r in p.itertuples(index=False):
        t = inc.tel10(r.telefono)
        n = inc.norm_nombre(r.nombre, r.apellidoP, r.apellidoM)
        if t: por_tel.setdefault(t, r.idPersona)
        if n: por_nom.setdefault(n, r.idPersona)
    regs = []
    for r in libro:
        nom = inc.norm_nombre(r.get('nombre'), r.get('apellido_paterno'), r.get('ApellidoM'))
        tel = inc.tel10(r.get('Teléfono'))
        if not nom and not tel:
            continue
        regs.append({'nombre': c02.titulo(r.get('nombre', '')), 'apellidoP': c02.titulo(r.get('apellido_paterno', '')),
                     'apellidoM': c02.titulo(r.get('ApellidoM', '')), 'sexo': r.get('_sexo_libro', '') or '', 'edad': '',
                     'telefono': tel, 'curp': c02.curp_valida(r.get('CURP', '')), 'correo': '',
                     'colonia': c02.titulo(r.get('colonia', '')), 'territorial': c02.titulo(r.get('Territorial', '')),
                     'nom_norm': nom, 'origen': r.get('dependencia_origen') or r.get('Dependencia', '') or 'Servicios Urbanos'})
    cand, tocadas = {}, 0
    for r in regs:
        if r['telefono'] and r['telefono'] in por_tel:
            tocadas += 1; continue
        if not r['telefono'] and r['nom_norm'] in por_nom:
            tocadas += 1; continue
        k = ('T', r['telefono']) if r['telefono'] else ('N', r['nom_norm'])
        if k in cand:
            for campo in ('curp', 'correo', 'edad', 'colonia', 'territorial', 'sexo'):
                if not cand[k][campo] and r[campo]:
                    cand[k][campo] = r[campo]
            cand[k]['origenes'].add(r['origen']); cand[k]['nRegistros'] += 1
        else:
            cand[k] = dict(r, origenes={r['origen']}, nRegistros=1)
    con_tel = {v['nom_norm']: k for k, v in cand.items() if k[0] == 'T' and v['nom_norm']}
    for k in [k for k in cand if k[0] == 'N' and cand[k]['nom_norm'] in con_tel]:
        d = cand[con_tel[cand[k]['nom_norm']]]
        d['origenes'] |= cand[k]['origenes']; d['nRegistros'] += cand[k]['nRegistros']
        del cand[k]
    ini = int(p['idPersona'].astype(int).max()) + 1
    etiq = 'Delta ' + _etiqueta(corte)[:2] + _etiqueta(corte)[2:5].capitalize() + _etiqueta(corte)[7:]
    filas = []
    for i, (k, r) in enumerate(sorted(cand.items(), key=lambda kv: kv[1]['nom_norm'])):
        ident = 'telefono+nombre' if r['telefono'] and r['nom_norm'] else 'telefono' if r['telefono'] else 'nombre'
        filas.append({'idPersona': ini + i, 'nombre': r['nombre'], 'apellidoP': r['apellidoP'], 'apellidoM': r['apellidoM'],
                      'sexo': r['sexo'], 'edad': r['edad'], 'telefono': r['telefono'], 'curp': r['curp'], 'correo': r['correo'],
                      'colonia': r['colonia'], 'territorial': r['territorial'],
                      'clasificacion': 'Identificable (tel + nombre)' if r['telefono'] and r['nom_norm'] else 'Identificable (nombre)',
                      'identificacion': ident, 'procedencia': 'Delta CUH3Jun', 'fuentes': etiq,
                      'origenes': ' | '.join(sorted(r['origenes'])), 'nRegistros': r['nRegistros']})
    out = pd.concat([p, pd.DataFrame(filas)], ignore_index=True)
    log(f'  {tocadas:,} ya estaban · {len(filas):,} personas nuevas · padrón: {len(out):,}')
    return out, {'previas': len(p), 'altas': len(filas), 'ya_estaban': tocadas,
                 'por_dep': dict(collections.Counter(x for r in cand.values() for x in r['origenes']).most_common())}


# ───────────────────────────────────────────────────────────────── salida
def emite(salida, corte, filas, padron_df, info, avisos, log, previos_cosmos):
    et = _etiqueta(corte)
    os.makedirs(salida, exist_ok=True)
    # base única
    csv_base = os.path.join(salida, f'BASE_UNICA_{corte}.csv')
    with open(csv_base, 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=COLS_BASE); w.writeheader()
        for r in filas: w.writerow({c: r.get(c, '') for c in COLS_BASE})
    sql_base = os.path.join(salida, f'BASE_UNICA_{et}.sql')
    with open(sql_base, 'w', encoding='utf-8') as f:
        f.write(f'''-- =====================================================================
-- BASE ÚNICA DE ATENCIONES {corte} -> public."BaseUnica"  ({len(filas):,} registros)
-- 20 columnas del layout + Canal, Naturaleza, dependencia_origen, servicio_origen + id. Dependencia y servicio ya normalizados al Directorio.
-- NO es el padrón: son atenciones; el Folio no es llave primaria. REBUILD completo: DROP + CREATE + todos los INSERT.
-- =====================================================================
BEGIN;
DROP TABLE IF EXISTS public."BaseUnica";
CREATE TABLE public."BaseUnica" (
  id integer PRIMARY KEY, nombre text, apellido_paterno text, "ApellidoM" text, "Sexo" text,
  "Teléfono" text, colonia text, "Territorial" text, seccion text, calle text, numero text,
  "Nacimiento" text, "CURP" text, "Nacionalidad" text, fecha text, lat double precision,
  lng double precision, observaciones text, "Dependencia" text, servicio text, "Folio" text, "Canal" text, "Naturaleza" text, dependencia_origen text, servicio_origen text);
ALTER TABLE public."BaseUnica" OWNER TO neondb_owner;
''')
        cl = 'id,' + ','.join('"%s"' % c for c in COLS_BASE)
        B = 1000
        for s in range(0, len(filas), B):
            f.write(f'INSERT INTO public."BaseUnica" ({cl}) VALUES\n')
            vals = []
            for j, r in enumerate(filas[s:s + B]):
                cel = []
                for c in COLS_BASE:
                    v = str(r.get(c, '') if r.get(c, '') is not None else '').replace('\x00', '')
                    if v == '': cel.append('NULL')
                    elif c in ('lat', 'lng'): float(v); cel.append(v)
                    else: cel.append("'" + v.replace("'", "''") + "'")
                vals.append('(' + str(s + j + 1) + ',' + ','.join(cel) + ')')
            f.write(',\n'.join(vals) + ';\n')
        f.write('CREATE INDEX ON public."BaseUnica" ("Dependencia");\nCREATE INDEX ON public."BaseUnica" ("Teléfono");\nCREATE INDEX ON public."BaseUnica" ("Canal");\nCREATE INDEX ON public."BaseUnica" ("Folio");\nCOMMIT;\n')
    # padrón
    csv_pad = os.path.join(salida, f'PADRON_FINAL_{corte}.csv')
    sql_pad = os.path.join(salida, f'PADRON_FINAL_{et}.sql')
    if padron_df is None:
        csv_pad = sql_pad = None
        padron_df = pd.DataFrame(columns=COLS_PADRON)
    else:
        padron_df.to_csv(csv_pad, index=False)
    with open(sql_pad or os.devnull, 'w', encoding='utf-8') as f:
        f.write(f'''-- =====================================================================
-- PADRÓN FINAL {corte} -> public."Padron"  ({len(padron_df):,} personas únicas)
-- Incremental sobre el padrón anterior ({info["pad"]["previas"]:,}); base aprobada CONGELADA; +{info["pad"]["altas"]:,} personas nuevas.
-- Sin SUAC ni Amazónica (el padrón nunca los cuenta). REBUILD completo.
-- =====================================================================
BEGIN;
DROP TABLE IF EXISTS public."Padron";
CREATE TABLE public."Padron" (
  "idPersona" integer PRIMARY KEY, nombre text, "apellidoP" text, "apellidoM" text, sexo text,
  edad integer, telefono text, curp text, correo text, colonia text, territorial text,
  clasificacion text NOT NULL, identificacion text NOT NULL, procedencia text NOT NULL,
  fuentes text, origenes text, "nRegistros" integer NOT NULL DEFAULT 1,
  "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL);
ALTER TABLE public."Padron" OWNER TO neondb_owner;

''')
        for r in padron_df.fillna('').to_dict('records'):
            f.write('INSERT INTO public."Padron" ("idPersona",nombre,"apellidoP","apellidoM",sexo,edad,telefono,curp,correo,colonia,territorial,clasificacion,identificacion,procedencia,fuentes,origenes,"nRegistros") VALUES ('
                    + ','.join([_qi(r['idPersona']), _q(r['nombre']), _q(r['apellidoP']), _q(r['apellidoM']), _q(r['sexo']), _qi(r['edad']), _q(r['telefono']), _q(r['curp']),
                                _q(r['correo']), _q(r['colonia']), _q(r['territorial']), _q(r['clasificacion']), _q(r['identificacion']), _q(r['procedencia']),
                                _q(r['fuentes']), _q(r['origenes']), _qi(r['nRegistros'])]) + ');\n')
        f.write('\nCOMMIT;\n')
    if sql_pad is None and os.path.exists(os.devnull): pass
    shutil.copy(os.path.join(AQUI, 'motor', 'catalogo', 'DEPENDENCIAS_SERVICIOS_CORREGIDO.csv'), salida)
    # estadísticas
    cdep = collections.Counter(r['Dependencia'] for r in filas)
    ccan = collections.Counter(r['Canal'] for r in filas)
    fol = collections.Counter(r['Folio'] for r in filas)
    fech = [r['fecha'] for r in filas if r.get('fecha')]
    info['n_base'], info['n_pad'] = len(filas), len(padron_df)
    # auditoría
    with open(os.path.join(salida, 'AUDITORIA.md'), 'w', encoding='utf-8') as fh:
        fh.write(f'# Auditoría · corte {corte}\n\n**{len(filas):,} registros** · {len(COLS_BASE)} columnas · **{len(padron_df):,} personas** en el padrón.\n\n## Fuentes\n\n| canal | registros |\n|---|---:|\n')
        for k, v in ccan.most_common(): fh.write(f'| {k} | {v:,} |\n')
        fh.write('\n## Por dependencia (Directorio)\n\n| dependencia | registros |\n|---|---:|\n')
        for k, v in cdep.most_common(): fh.write(f'| {k} | {v:,} |\n')
        fh.write(f'\n## Llave\n\n- folios distintos: {len(fol):,}; repetidos: {sum(1 for n in fol.values() if n > 1):,}\n- fechas de atención: {min(fech)} → {max(fech)}\n')
        fh.write('\n## Fecha más reciente por fuente\n\n| fuente | última fecha |\n|---|---|\n')
        for k, v in sorted(info['base']['ult'].items()): fh.write(f'| {k} | {v} |\n')
        fh.write('\n## Normalización\n\n')
        for k, v in info['base']['stat'].items(): fh.write(f'- {k}: **{v:,}**\n')
    # avisos
    with open(os.path.join(salida, 'AVISOS_PARA_ANA.md'), 'w', encoding='utf-8') as fh:
        fh.write(f'# Avisos del corte {corte}\n\n')
        fh.write('## Para pedir a las áreas (los atiende Ana)\n\n' + ('\n'.join('- ' + a for a in avisos['ana']) if avisos['ana'] else '- Nada: llegó todo.') + '\n\n')
        fh.write('## Para que decida Emilio\n\n' + ('\n'.join('- ' + a for a in avisos['emilio']) if avisos['emilio'] else '- Nada pendiente.') + '\n')
    # LEEME para IT
    tabla = '\n'.join(f'| {k} | {v:,} |' for k, v in cdep.most_common())
    with open(os.path.join(salida, 'LEEME_IT.md'), 'w', encoding='utf-8') as fh:
        fh.write(f'''# Entrega IT · corte {corte}

Dos tablas, ambas **REBUILD completo** (cada `.sql` hace `DROP TABLE IF EXISTS` + `CREATE TABLE` + todos los `INSERT`, dentro de `BEGIN … COMMIT`).

| archivo | tabla | filas |
|---|---|---:|
{'| `PADRON_FINAL_' + et + '.sql` | `public."Padron"` | **' + format(len(padron_df), ',') + '** |' if sql_pad else '| (sin padrón en este paquete) | | |'}
| `BASE_UNICA_{et}.sql` | `public."BaseUnica"` | **{len(filas):,}** |
{previos_cosmos}
## Cómo cargar
Con `psql`, **no** con interfaz web:

    {'psql "$DATABASE_URL" -f PADRON_FINAL_' + et + '.sql' if sql_pad else '(sin padrón en este paquete)'}
    psql "$DATABASE_URL" -f BASE_UNICA_{et}.sql

Verificación al terminar:

    {'SELECT count(*) FROM public."Padron";      -- ' + str(len(padron_df)) if sql_pad else '-- (sin padrón)'}
    SELECT count(*) FROM public."BaseUnica";   -- {len(filas)}
    SELECT max(fecha) FROM public."BaseUnica";  -- {max(fech)}

Antes de cargar, confirmar la estructura actual con `\\d public."Padron"` y `\\d public."BaseUnica"`. Si el Directorio no está cargado en `directorates` / `directorate-services`, cargar `DEPENDENCIAS_SERVICIOS_CORREGIDO.csv` primero.

## BaseUnica · registros por dependencia (para verificar)

| dependencia | registros |
|---|---:|
{tabla}

Generado por Nebula. El padrón y la base única son productos distintos: personas vs. atenciones; no se suman ni se comparan.
''')
    # huellas y zip
    with open(os.path.join(salida, 'SHA256.txt'), 'w') as fh:
        for n in sorted(os.listdir(salida)):
            if n.endswith('.sql'): fh.write(f'{_sha(os.path.join(salida, n))}  {n}\n')
    return {'csv_base': csv_base, 'csv_padron': csv_pad, 'sql_base': sql_base, 'sql_padron': sql_pad}


def paquete(salida, corte):
    z = os.path.join(os.path.dirname(salida), f'NEBULA_{corte}_para_IT.zip')
    with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as zf:
        for n in sorted(os.listdir(salida)):
            if n.endswith(('.sql', '.md', '.txt')) or n.startswith('DEPENDENCIAS'):
                zf.write(os.path.join(salida, n), os.path.join(f'NEBULA_{corte}', n))
    return z


def correr(concentrado, suac, amazonica, padron_previo, corte, salida, base_previa=None, log=print, sueltos=()):
    avisos = {'ana': [], 'emilio': []}
    filas, previo, libro, ib = base_unica(concentrado, suac, amazonica, corte, base_previa, avisos, log, sueltos)
    if padron_previo:
        pad, ip = padron([r for r in libro], padron_previo, corte, log)
    else:
        pad, ip = None, {'previas': 0, 'altas': 0, 'ya_estaban': 0, 'por_dep': {}}
        avisos['emilio'].append('No se subió el padrón del corte anterior: este paquete trae SOLO la base única de atenciones, sin padrón. Sube el padrón anterior (.csv) para generarlo.')
        log('Sin padrón anterior: se prepara solo la base única.')
    info = {'base': ib, 'pad': ip}
    arch = emite(salida, corte, filas, pad, info, avisos, log, '')
    z = paquete(salida, corte)
    log(f'Listo → {z}')
    return {'zip': z, 'archivos': arch, 'avisos': avisos, 'filas': len(filas), 'personas': len(pad) if pad is not None else 0, 'altas': ip['altas']}

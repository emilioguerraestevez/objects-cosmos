#!/usr/bin/env python3
"""Formulario de registro único — captura directa al MasterLayout.

Reemplaza el envío semanal de Excel por dependencia: cada área captura su
propia atención aquí, en el momento, con el catálogo de servicios real (el
mismo que se limpió esta semana en cuauhtemoc.db) en vez de texto libre.

El contrato es el mismo de siempre — LAYOUT en base_unica.py — más metadata
de captura (quién, cuándo, desde dónde). Los registros nuevos NO se mezclan
con cuauhtemoc.db automáticamente: caen en su propia tabla `registros`, con
fuente='Formulario', para que el corte semanal los incorpore igual que hoy
incorpora al SUAC o a las listas de las dependencias.

    /Users/ege/Documents/Proyectos/eureka/.venv/bin/uvicorn app:app --port 8790 --reload
"""
import base64
import csv
import hashlib
import os
import re
import sqlite3
import unicodedata
from collections import defaultdict
from datetime import date, datetime

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

BASE = os.path.dirname(os.path.abspath(__file__))


def b64(ruta):
    """Los PNG en assets/ ya vienen sin fondo (recortados con Pillow al empaquetar);
    aquí solo se embeben, para no cargar Pillow como dependencia de este servicio."""
    if not os.path.exists(ruta):
        return ''
    with open(ruta, 'rb') as f:
        return base64.b64encode(f.read()).decode()


ESCUDO = b64(os.path.join(BASE, 'assets', 'escudo_limpio.png'))
ANDROMEDA = b64(os.path.join(BASE, 'assets', 'andromeda_limpio.png'))
CATALOGO = os.path.join(BASE, 'catalogo', 'CATALOGO_SERVICIOS.csv')
DB = os.path.join(BASE, 'registros.db')
CODIGO_ACCESO = 'cuh2026'  # cámbialo antes de repartir el link

DEP_ORDEN = ['Servicios Urbanos', 'Desarrollo Social', 'Participación Ciudadana',
             'Genero', 'Cultura', 'Jurídico', 'Gobierno', 'Seguridad',
             'Protección Civil', 'Obras', 'Administración', 'Oficina de la Alcaldía']
DEP_ETIQUETA = {'Genero': 'Igualdad de Género'}


def sa(s):
    s = unicodedata.normalize('NFD', str(s or ''))
    return ''.join(c for c in s if unicodedata.category(c) != 'Mn').upper()


def cargar_catalogo():
    servicios = defaultdict(set)
    with open(CATALOGO, encoding='utf-8') as f:
        for r in csv.DictReader(f):
            servicios[r['clave_padron']].add(r['servicio'].strip())
    return {k: sorted(v) for k, v in servicios.items() if k in DEP_ORDEN}


SERVICIOS = cargar_catalogo()


def init_db():
    cx = sqlite3.connect(DB)
    cx.execute('''create table if not exists registros(
        id integer primary key autoincrement,
        folio text, nombre text, apellido_paterno text, apellido_materno text,
        sexo text, telefono text, colonia text, territorial text, seccion text,
        calle text, numero text, nacimiento text, curp text, nacionalidad text,
        fecha text, lat real, lng real, observaciones text,
        dependencia text not null, servicio text not null,
        fuente text default 'Formulario', capturado_por text, capturado_en text not null,
        incorporado integer default 0
    )''')
    cx.execute('create index if not exists idx_reg_dep on registros(dependencia)')
    cx.commit()
    cx.close()


init_db()
app = FastAPI(title='Formulario único de registro — Alcaldía Cuauhtémoc')


def tel10(v):
    d = re.sub(r'\D', '', v or '')
    return d[-10:] if len(d) >= 10 else d


def folio_sintetico(dep, nombre, ap, tel, fecha, servicio):
    firma = '|'.join((sa(nombre), sa(ap), tel10(tel), fecha, sa(servicio)))
    h = hashlib.sha1(firma.encode()).hexdigest()[:10].upper()
    return f'CUH/{sa(dep).replace(" ", "")[:8]}/{h}'


class Registro(BaseModel):
    codigo: str
    dependencia: str
    servicio: str
    nombre: str = ''
    apellido_paterno: str = ''
    apellido_materno: str = ''
    sexo: str = ''
    telefono: str = ''
    colonia: str = ''
    territorial: str = ''
    seccion: str = ''
    calle: str = ''
    numero: str = ''
    nacimiento: str = ''
    curp: str = ''
    nacionalidad: str = ''
    fecha: str = ''
    lat: str = ''
    lng: str = ''
    observaciones: str = ''
    folio: str = ''
    capturado_por: str = ''


@app.get('/api/servicios')
def api_servicios(dependencia: str):
    if dependencia not in SERVICIOS:
        raise HTTPException(404, 'dependencia desconocida')
    return SERVICIOS[dependencia]


@app.post('/api/registro')
def api_registro(r: Registro):
    if r.codigo != CODIGO_ACCESO:
        raise HTTPException(401, 'código de acceso incorrecto')
    if r.dependencia not in SERVICIOS:
        raise HTTPException(400, 'dependencia desconocida')
    if r.servicio not in SERVICIOS[r.dependencia]:
        raise HTTPException(400, 'ese servicio no pertenece al catálogo de esta dependencia')
    if not (r.nombre.strip() or r.telefono.strip() or r.folio.strip()):
        raise HTTPException(400, 'necesita al menos nombre, teléfono o folio')

    fecha = r.fecha.strip() or date.today().isoformat()
    tel = tel10(r.telefono)
    folio = r.folio.strip() or folio_sintetico(r.dependencia, r.nombre, r.apellido_paterno,
                                                tel, fecha, r.servicio)
    lat = float(r.lat) if r.lat.strip() else None
    lng = float(r.lng) if r.lng.strip() else None

    cx = sqlite3.connect(DB)
    cx.execute('''insert into registros(folio, nombre, apellido_paterno, apellido_materno, sexo,
        telefono, colonia, territorial, seccion, calle, numero, nacimiento, curp, nacionalidad,
        fecha, lat, lng, observaciones, dependencia, servicio, capturado_por, capturado_en)
        values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
        (folio, r.nombre.strip(), r.apellido_paterno.strip(), r.apellido_materno.strip(),
         r.sexo, tel, r.colonia.strip(), r.territorial.strip(), r.seccion.strip(),
         r.calle.strip(), r.numero.strip(), r.nacimiento.strip(), r.curp.strip().upper(),
         r.nacionalidad.strip(), fecha, lat, lng, r.observaciones.strip(),
         r.dependencia, r.servicio, r.capturado_por.strip(), datetime.now().isoformat(timespec='seconds')))
    cx.commit()
    cx.close()
    return {'ok': True, 'folio': folio}


@app.get('/api/resumen')
def api_resumen(codigo: str):
    if codigo != CODIGO_ACCESO:
        raise HTTPException(401, 'código de acceso incorrecto')
    cx = sqlite3.connect(DB)
    rows = cx.execute('''select dependencia, count(*) n, max(capturado_en) ultimo
                          from registros group by 1 order by 2 desc''').fetchall()
    cx.close()
    return [{'dependencia': d, 'registros': n, 'ultimo': u} for d, n, u in rows]


HTML = r'''<!doctype html><html lang=es><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>Registro único · Alcaldía Cuauhtémoc</title>
<style>
:root{--ink:#1a1a1a;--mut:#6b6b70;--line:#dfe1e5;--verde:#1a7f37;--rojo:#8f1d2c;--marca:#f6e359}
*{box-sizing:border-box}
body{font:15px/1.5 -apple-system,'Barlow',system-ui,sans-serif;color:var(--ink);background:#fafafa;
 margin:0;padding:24px 16px 60px}
.env{max-width:640px;margin:0 auto}
h1{font-size:22px;margin:0 0 2px}
.sub{color:var(--mut);font-size:13.5px;margin-bottom:22px}
label{display:block;font-size:12.5px;font-weight:600;color:var(--mut);margin:16px 0 5px;
 text-transform:uppercase;letter-spacing:.03em}
input,select,textarea{width:100%;padding:11px 12px;border:1px solid var(--line);border-radius:9px;
 font-size:16px;font-family:inherit;background:#fff}
textarea{min-height:70px;resize:vertical}
.fila{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.tarjeta{background:#fff;border:1px solid var(--line);border-radius:14px;padding:20px 20px 4px;
 margin-bottom:16px}
button{width:100%;padding:14px;border:0;border-radius:10px;background:var(--ink);color:#fff;
 font-size:16px;font-weight:600;margin-top:22px;cursor:pointer}
button:disabled{opacity:.5}
.msg{margin-top:14px;padding:12px 14px;border-radius:9px;font-size:14px;display:none}
.msg.ok{display:block;background:#eaf6ec;color:var(--verde);border:1px solid #bfe3c6}
.msg.err{display:block;background:#fbecec;color:var(--rojo);border:1px solid #f0c4c4}
.gate{max-width:340px;margin:80px auto;text-align:center}
.gate input{text-align:center;font-size:20px;letter-spacing:.1em}
.oculto{display:none}
small.ayuda{color:var(--mut);display:block;margin-top:4px;font-size:12px}
.escudo{height:56px;margin:0 auto 14px;display:block}
.tope{display:flex;align-items:center;gap:12px;margin-bottom:2px}
.tope .escudo{height:40px;margin:0}
.pieMarca{display:flex;align-items:center;justify-content:center;gap:8px;margin:30px 0 10px;
 opacity:.55}
.pieMarca img{height:16px}
.pieMarca span{font-size:11px;color:var(--mut);letter-spacing:.03em}
</style></head><body>

<div id=gate class=gate>
 <img class=escudo src="data:image/png;base64,{{ESCUDO}}">
 <h1>Registro único</h1>
 <p class=sub>Alcaldía Cuauhtémoc — captura directa a la base maestra</p>
 <label>Código de acceso</label>
 <input id=codigo type=password placeholder="código">
 <button onclick="entrar()">Entrar</button>
 <div id=gateMsg class="msg"></div>
</div>

<div id=form class="env oculto">
<div class=tope><img class=escudo src="data:image/png;base64,{{ESCUDO}}"><h1 style="margin:0">Registro de atención ciudadana</h1></div>
<p class=sub>Un registro por persona atendida. El servicio sale del catálogo oficial de tu dependencia.</p>

<div class=tarjeta>
<label>Dependencia</label>
<select id=dependencia onchange="cargaServicios()"></select>

<label>Servicio</label>
<select id=servicio><option value="">Selecciona primero la dependencia…</option></select>
</div>

<div class=tarjeta>
<div class=fila>
 <div><label>Nombre</label><input id=nombre></div>
 <div><label>Sexo</label><select id=sexo><option value=""></option><option>Mujer</option><option>Hombre</option></select></div>
</div>
<div class=fila>
 <div><label>Apellido paterno</label><input id=apellido_paterno></div>
 <div><label>Apellido materno</label><input id=apellido_materno></div>
</div>
<div class=fila>
 <div><label>Teléfono</label><input id=telefono inputmode=numeric maxlength=10></div>
 <div><label>CURP</label><input id=curp maxlength=18 style="text-transform:uppercase"></div>
</div>
</div>

<div class=tarjeta>
<div class=fila>
 <div><label>Colonia</label><input id=colonia></div>
 <div><label>Territorial</label><input id=territorial></div>
</div>
<div class=fila>
 <div><label>Calle</label><input id=calle></div>
 <div><label>Número</label><input id=numero></div>
</div>
<div class=fila>
 <div><label>Sección</label><input id=seccion inputmode=numeric></div>
 <div><label>Fecha de atención</label><input id=fecha type=date></div>
</div>
<button type=button onclick="ubicar()" style="background:#fff;color:var(--ink);border:1px solid var(--line);margin-top:14px">📍 Usar mi ubicación</button>
<small class=ayuda id=geoMsg></small>
</div>

<div class=tarjeta>
<label>Observaciones</label>
<textarea id=observaciones placeholder="Lo que no cabe en los campos de arriba"></textarea>
<div class=fila>
 <div><label>Folio (si ya tiene uno)</label><input id=folio></div>
 <div><label>Capturado por</label><input id=capturado_por placeholder="tu nombre"></div>
</div>
</div>

<button id=enviar onclick="enviar()">Guardar registro</button>
<div id=msg class=msg></div>
<div class=pieMarca><img src="data:image/png;base64,{{ANDROMEDA}}"><span>cosmos.ai</span></div>
</div>

<script>
const CAT = {};
let CODIGO = '';

function entrar(){
  CODIGO = document.getElementById('codigo').value.trim();
  if(!CODIGO){ return; }
  fetch('/api/resumen?codigo=' + encodeURIComponent(CODIGO)).then(r=>{
    if(!r.ok){ const m=document.getElementById('gateMsg'); m.className='msg err'; m.textContent='Código incorrecto.'; return; }
    document.getElementById('gate').classList.add('oculto');
    document.getElementById('form').classList.remove('oculto');
    initForm();
  });
}
document.getElementById('codigo').addEventListener('keydown', e=>{ if(e.key==='Enter') entrar(); });

function initForm(){
  document.getElementById('fecha').value = new Date().toISOString().slice(0,10);
  const params = new URLSearchParams(location.search);
  const depSel = document.getElementById('dependencia');
  DEPS.forEach(d=>{
    const o = document.createElement('option'); o.value = d[0]; o.textContent = d[1];
    depSel.appendChild(o);
  });
  const forzada = params.get('dep');
  if(forzada && DEPS.some(d=>d[0]===forzada)){
    depSel.value = forzada; depSel.disabled = true;
  }
  cargaServicios();
}

function cargaServicios(){
  const dep = document.getElementById('dependencia').value;
  const sel = document.getElementById('servicio');
  if(CAT[dep]){ llenaServicios(CAT[dep]); return; }
  sel.innerHTML = '<option>Cargando…</option>';
  fetch('/api/servicios?dependencia=' + encodeURIComponent(dep)).then(r=>r.json()).then(list=>{
    CAT[dep] = list; llenaServicios(list);
  });
}
function llenaServicios(list){
  const sel = document.getElementById('servicio');
  sel.innerHTML = '';
  list.forEach(s=>{ const o = document.createElement('option'); o.value = s; o.textContent = s; sel.appendChild(o); });
}

function ubicar(){
  if(!navigator.geolocation){ document.getElementById('geoMsg').textContent='Este navegador no da ubicación.'; return; }
  navigator.geolocation.getCurrentPosition(pos=>{
    window._lat = pos.coords.latitude; window._lng = pos.coords.longitude;
    document.getElementById('geoMsg').textContent = 'Ubicación capturada (' + window._lat.toFixed(5) + ', ' + window._lng.toFixed(5) + ')';
  }, ()=>{ document.getElementById('geoMsg').textContent = 'No se pudo obtener la ubicación.'; });
}

function enviar(){
  const btn = document.getElementById('enviar'); btn.disabled = true;
  const g = id => document.getElementById(id).value;
  const body = {
    codigo: CODIGO, dependencia: g('dependencia'), servicio: g('servicio'),
    nombre: g('nombre'), apellido_paterno: g('apellido_paterno'), apellido_materno: g('apellido_materno'),
    sexo: g('sexo'), telefono: g('telefono'), colonia: g('colonia'), territorial: g('territorial'),
    seccion: g('seccion'), calle: g('calle'), numero: g('numero'), nacimiento: '', curp: g('curp'),
    nacionalidad: '', fecha: g('fecha'), lat: window._lat ? String(window._lat) : '',
    lng: window._lng ? String(window._lng) : '', observaciones: g('observaciones'),
    folio: g('folio'), capturado_por: g('capturado_por')
  };
  fetch('/api/registro', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)})
    .then(async r => {
      const msg = document.getElementById('msg'); btn.disabled = false;
      if(!r.ok){ const e = await r.json(); msg.className='msg err'; msg.textContent = e.detail || 'Error al guardar.'; return; }
      const data = await r.json();
      msg.className='msg ok'; msg.textContent = 'Guardado — folio ' + data.folio + '. Puedes capturar el siguiente.';
      ['nombre','apellido_paterno','apellido_materno','telefono','curp','calle','numero','seccion',
       'observaciones','folio','colonia'].forEach(id=>document.getElementById(id).value='');
      document.getElementById('sexo').value='';
      window._lat = window._lng = null; document.getElementById('geoMsg').textContent='';
    });
}
</script>
</body></html>'''


@app.get('/', response_class=HTMLResponse)
def index():
    deps = [[d, DEP_ETIQUETA.get(d, d)] for d in DEP_ORDEN if d in SERVICIOS]
    js = 'const DEPS = ' + str(deps).replace("'", '"') + ';\n'
    pagina = HTML.replace('<script>', '<script>' + js, 1)
    pagina = pagina.replace('{{ESCUDO}}', ESCUDO).replace('{{ANDROMEDA}}', ANDROMEDA)
    return pagina

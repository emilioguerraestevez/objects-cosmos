#!/usr/bin/env python3
"""Incorpora los registros nuevos del formulario a la base maestra.

Referencia para IT: corre una vez por semana, igual cadencia que el SUAC y
las listas de las dependencias (decisión del usuario, 24-ago-2026). No
duplica: cada registro incorporado se marca `incorporado=1` en registros.db
y no vuelve a tomarse la próxima corrida.

Ajustar rutas si `cuauhtemoc.db` vive en otro lugar o la infraestructura
oficial usa otro motor de base de datos — la lógica (leer no incorporados,
insertar, marcar) es la parte que importa conservar.

    python3 incorporar_formulario.py
"""
import os
import sqlite3

BASE = os.path.dirname(os.path.abspath(__file__))
REGISTROS = os.path.join(BASE, 'registros.db')
MAESTRA = os.path.join(BASE, '..', 'base_unica', 'cuauhtemoc.db')

CAMPOS = ['folio', 'nombre', 'apellido_paterno', 'apellido_materno', 'sexo', 'telefono',
          'colonia', 'territorial', 'seccion', 'calle', 'numero', 'nacimiento', 'curp',
          'nacionalidad', 'fecha', 'lat', 'lng', 'observaciones', 'dependencia', 'servicio',
          'fuente']


def main():
    rg = sqlite3.connect(REGISTROS)
    nuevos = rg.execute(f'''select id, {", ".join(CAMPOS)} from registros
                             where incorporado = 0''').fetchall()
    if not nuevos:
        print('nada que incorporar')
        return

    ma = sqlite3.connect(MAESTRA)
    placeholders = ', '.join('?' * len(CAMPOS))
    for fila in nuevos:
        id_, *valores = fila
        ma.execute(f'''insert into solicitudes ({", ".join(c.lower() for c in CAMPOS)})
                        values ({placeholders})''', valores)
        rg.execute('update registros set incorporado = 1 where id = ?', (id_,))
    ma.commit()
    rg.commit()
    ma.close()
    rg.close()
    print(f'{len(nuevos)} registros incorporados a cuauhtemoc.db')


if __name__ == '__main__':
    main()
